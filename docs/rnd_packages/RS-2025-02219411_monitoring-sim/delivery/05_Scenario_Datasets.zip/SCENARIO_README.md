# Scenario · Dataset Assets

산출물 #4 — 적심·적과 농작업 로봇 관제 시각화 시뮬레이터의 시나리오·데이터셋 일체.

## 디렉토리 구조

```
04_Scenario_Datasets/
├── SCENARIO_README.md            본 문서
├── scenarios/                    런타임 시나리오 카탈로그/로더
│   ├── loader.ts                 시나리오 ID -> ScenarioSpec 매핑·검증
│   ├── types.ts                  ScenarioSpec / ScenarioId / 영역별 타입
│   ├── taskTargets.ts            작업별 목표 (적심·적과 카운트 등)
│   ├── metrics.ts                품종별 측정 지표
│   └── reference/literature.ts   학술 문헌 기반 검증 범위
├── showcaseSeed.ts               기본 시드 (SHOWCASE_SEED = 20260520)
└── tomato-engine-models/         식물 학술 모델 SSOT (5 layer 14 file)
    ├── INDEX.jsonc               전체 카탈로그
    ├── README.md                 모델 카탈로그 설명
    ├── tomgro-v1.jsonc           TOMGRO 학술 성장 모델
    ├── cultivars/                품종(cultivar) 설정 (Tomimaru 등)
    ├── botanical/                botanical layer (구조·기관)
    ├── training/                 training 시나리오 입력
    └── calibration/              calibration 기준값
```

## 시드 · 재현성

| 항목 | 값 |
|---|---|
| `SHOWCASE_SEED` (기본) | `20260520` (showcaseSeed.ts:4) |
| URL 오버라이드 | `?seed=<n>` |
| 결정성 보장 | `src/core/Determinism.ts:lockSeed()` 호출 후 모든 무작위성 시드로 고정 |
| 재현 검수 기준 | 같은 시드 + 같은 시나리오 ID -> 같은 식물 군집, 같은 트러스/잎/과실 위상, 같은 카메라 traverse 결과 |

## 시나리오 호출 패턴

```typescript
import { getScenarioById } from './scenarios/loader';

const scenario = getScenarioById('phenotyping-D110-survey');
// → ScenarioSpec { id, domain, crop: { day, seed, cultivar }, world, robot, task, env, ... }
```

`ScenarioSpec` 의 주요 필드 (`types.ts` 참조):
- `id`: 시나리오 식별자 (URL `?scenario=<id>`)
- `domain`: 시나리오 영역 (`phenotyping` 등)
- `crop.day`: 정착 후 일수 (식물 성장 단계)
- `crop.seed`: 결정성 시드 (URL `?seed=<n>` 오버라이드 가능)
- `crop.cultivar`: 품종 ID (tomato-engine-models/cultivars/*.jsonc)
- `world.bedLayout`: 베드 레이아웃 (`?bedLayout=2-4-4` 등)
- `world.activeBedIds`: 활성 베드 ID 목록 (`?activeBedIds=4,5,6,7,8,9` 등)
- `robot.profile`: 로봇 프로파일 (`phenotyping` 등)
- `robot.traverseEnabled`, `robot.gimbalView`: 로봇 동작 옵션
- `task.rule`: 작업 규칙 (예: `left-bed-on-forward,right-bed-on-return`)
- `task.speedMps`: traverse 속도 (m/s)
- `env.lightingPreset`, `env.manualHour`: 조명·시각 설정

## 베드 레이아웃 명세

| 레이아웃 ID | 베드 구성 | 활성 베드 예시 |
|---|---|---|
| `2-4-4` | 좌·우 베드 2쌍 (2 + 4 + 4) | `4,5,6,7,8,9` |
| (기타) | `scenarios/types.ts` 의 `BedLayoutId` union 참조 | — |

## 식물 학술 모델 (tomato-engine-models/)

5 layer · 14 file SSOT (CLAUDE.md "토마토 데이터 카탈로그" 원칙):
- **visual layer**: 잎·과실 시각 사양
- **physiology layer**: TOMGRO/TOMSIM 기반 생리학적 매개변수
- **botanical layer**: 식물 구조·기관 정의
- **cultivar layer**: 품종별 오버라이드 (Tomimaru 등)
- **training / calibration / diagnostic / audit layer**: 학습·캘리브레이션·진단·감사

각 파일에는 `"layer": "<key>"` 필드 필수. 카탈로그 SSOT 진입점은 `INDEX.jsonc`.

## 운용 시나리오 예시 — `phenotyping-D110-survey`

| 항목 | 값 |
|---|---|
| domain | `phenotyping` |
| crop.day | D110 (정착 후 110일) |
| crop.seed | `SHOWCASE_SEED` (또는 URL 오버라이드) |
| crop.cultivar | `tomimaru` 등 |
| robot.profile | `phenotyping` |
| robot.traverseEnabled | `true` |
| robot.gimbalView | `true` |
| task.rule | `left-bed-on-forward,right-bed-on-return` |
| 예상 traverse 시간 | ~45초/패스 (0.3 m/s, 14 m 반경) |

운용 매뉴얼(`06_User_Manual.pdf`)에 단계별 절차가 정리되어 있음.

## 재현 검수 흐름

```bash
# 1. 빌드 zip 압축 해제 후 정적 서버 시작
# 2. 브라우저에서 다음 URL 진입
http://localhost:<port>/?mode=workbench&scenario=phenotyping-D110-survey&seed=20260520&bedLayout=2-4-4&activeBedIds=4,5,6,7,8,9&robotProfile=phenotyping&robotTraverse=1&gimbalView=1

# 3. 결과 시트(Result Sheet) 값과 본 데이터셋의 기대 출력(시드별)을 대조
```

기대 출력은 검수 시험 결과 보고서(`09_Test_Report.pdf`)에 시드별로 기록.
