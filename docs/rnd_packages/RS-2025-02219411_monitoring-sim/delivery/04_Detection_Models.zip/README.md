# Detection Models — Asset Set

산출물 #3 — 적심·적과 농작업 로봇 관제 시각화 시뮬레이터의 디텍션 파이프라인 자산.

## 파일

| 파일 | 내용 |
|---|---|
| `yolov8n.onnx` | YOLOv8 nano (Ultralytics COCO-pretrained), 12.8 MB |
| `yolov8n.onnx.sha256` | 모델 무결성 해시 (SHA-256) |
| `model_metadata.json` | 입출력 텐서 사양, 클래스 매핑, 추론 임계값 |
| `hsv_parameters.json` | 5밴드 HSV ripeness 분류기 파라미터 + shape filter |
| `sample_inference.png` | 추론 입력 샘플 캡처 |
| `sample_inference.md` | 샘플 추론 결과 요약 |

## 사용 흐름 — 두 단계 디텍션 파이프라인

```
panorama frame
    |
    v  Stage 1 — Instance detection
[ONNX Runtime Web]
    |  yolov8n.onnx, conf >= 0.05, NMS IoU 0.45
    |  COCO fruit classes (46/47/49/53) -> tomato candidates
    v  bbox list
    |
    v  Stage 2 — Ripeness classification
[HSV bands per bbox]
    |  hsv_parameters.json (5 bands + shape filter)
    |
    v
final detections: { bbox, ripeness_bin, confidence }
```

## 무결성 검증

```bash
shasum -a 256 yolov8n.onnx
# 출력이 yolov8n.onnx.sha256과 일치해야 함
# 기대: b2bc52f40e8e1c532427d5bde3575a5d5b571b739fab2c6df443733ed1589cbd
```

## 라이선스

YOLOv8 weights: AGPL-3.0 (Ultralytics).  본 사업 적용 범위 — 시뮬레이션 환경 내 시연·검증 목적의 비상용 R&D 사용.
