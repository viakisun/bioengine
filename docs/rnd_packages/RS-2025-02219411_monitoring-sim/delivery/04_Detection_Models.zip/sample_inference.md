# Sample Inference Capture

**File**: `sample_inference.png`

**Source**: 시뮬레이터 운용 중 Playwright probe로 캡처한 메인 캔버스 이미지. 렌더된 온실 씬에 다양한 익음 단계의 토마토 과실(빨강·노랑·초록)이 substrate bag과 구조물을 배경으로 표시되어 있음.

## 추론 요약 (이 이미지에 본 두 단계 디텍션 파이프라인 적용 시)

| 단계 | 방법 | 결과 |
|---|---|---|
| 1 — Instance detection | YOLOv8 (ONNX Runtime Web, confidence >= 0.05) | Multiple fruit-class hits (apple/orange/banana/carrot) → 토마토 후보로 채택 |
| 2 — Ripeness classification | HSV bands + shape filter (`hsv_parameters.json` 참조) | 각 bbox에 5개 ripeness bin 중 하나 할당 (green / breaker / turning / pink / red) |

## 참고

본 캡처는 시뮬레이터가 만드는 씬의 종류와 모델에 입력되는 프레임의 모습을 보여주기 위한 참조 이미지입니다.  실제 운용 중 PiP 위에 그려지는 디텍션 오버레이는 운용 데모 영상(`10_Demo_Recording`)에서 확인할 수 있습니다.
