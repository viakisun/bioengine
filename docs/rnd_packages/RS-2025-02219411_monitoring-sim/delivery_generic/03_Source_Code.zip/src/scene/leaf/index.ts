// ★ Iter 39 Phase L4 — Leaf engine entry barrel.
//
// Engine layer (plant-agnostic — 원칙 #42). botanical data는 src/data/leaf/.
//
// 산식 SSOT: LeafMeshBuilder.ts (canonical entry buildLeafMeshFromSkeleton).
// Babylon wrapper: LeafMaterial.ts (wrapLeafChunksAsMeshes + materials).
// Spec: LeafSpec.ts (Zod schema + parseLeafSpec + resolveCultivar).
//
// 사용자 botanical reference §9 procedural 흐름:
//   skeleton → ctx.spec.agePresets[bladeRef.agePreset] → applyCorrelation →
//   per-leaflet outline (profile + lobe + serration) → pose → mesh chunk.

// ─── Legacy compound-leaf descriptor (Iter 36 Phase D) ─────────────────────
// ★ Iter 39 L4-5 (S33) — buildCompoundLeaf 함수 _제거_. production은
//   buildLeafMeshFromSkeleton 단일 사용. 잔존 type re-export만.

// ─── Legacy types (예비) ───────────────────────────────────────────────────

export interface CultivarShapeOverride {
  aspectRatioMultiplier?: number;
  baseShapeBias?: number;
  tipSharpnessMultiplier?: number;
}

// ─── Re-exports — engine entry ─────────────────────────────────────────────

export type { ResolvedLeafParams } from './LeafMeshBuilder';
// ★ L5-7 (S44) — AGE_PRESETS 제거 (tomato.json 중복). caller는 getLeafSpec.
export type { LeafletMeshBuildContext } from './LeafMeshBuilder';

// ★ Canonical entry — buildLeafMeshFromSkeleton{spec, ctx}.
export { buildLeafMeshFromSkeleton } from './LeafMeshBuilder';
export type { LeafMeshBuildInput, LeafMeshPatch } from './LeafMeshBuilder';

// L4-6 (S34) LeafEngine namespace — recommended API.
export { LeafEngine } from './LeafEngine';
export type { CreateLeafOptions } from './LeafEngine';

// L2-3 per-leaflet position profile.
export { PROFILE_BY_POSITION, applyPositionProfile } from './LeafMeshBuilder';
export type { LeafletPosition, LeafletShapeProfile } from './LeafMeshBuilder';

// ★ L5-4 (S41) — leaf-instance macro 분해. LeafInstanceProfile 6-field 폐기,
//   live 1-field만 보존하는 `computeLeftRightImbalance`로 대체. computeLeafletPose
//   (deg-based, 호출처 0) 완전 제거.
// ★ L6-A-6 (S51) — leaf-level macro variation 재도입 (computeLeafMacroState).
//   step 1: 산출만, mesh path 미연결 (S52에서 연결).
export { computeLeftRightImbalance, computeLeafMacroState } from './LeafMeshBuilder';
export type { LeafMacroState } from './LeafMeshBuilder';

// L6-B-2 (S58) — LOD distance-based quality selection.
export { qualityFromDistance } from './LeafletProfile';
export type { LeafMeshQuality, LeafMeshResolution } from './LeafletProfile';
export { LEAF_MESH_RESOLUTION } from './LeafletProfile';

// L4-3 LeafSpec + Zod runtime validation.
export type {
  LeafSpec,
  AgePresetParams,
  ProfileByPosition,
  CorrelationRules,
  PoseRules,
  CultivarOverride,
  Taxonomy,
} from './LeafSpec';
export {
  LeafSpecSchema,
  AgePresetSchema,
  PositionProfileSchema,
  ProfileByPositionSchema,
  CorrelationRulesSchema,
  PoseRulesSchema,
  CultivarOverrideSchema,
  TaxonomySchema,
  parseLeafSpec,
  resolveCultivar,
} from './LeafSpec';

