/**
 * StemGenerator — procedural tube mesh through a chain of NodeStates.
 *
 *   • Single source of truth: every node.position is consumed *as-is*; the
 *     mesh just sweeps a tapered tube along the wandering polyline.
 *   • Per-call polish knobs (radial segments, node bulge, vertical stripe)
 *     so showcase plants can opt into higher detail without paying the
 *     cost on 720-plant greenhouse renders.
 *   • Catmull-Rom utilities re-exported for SkeletonOverlay reuse.
 */

import { Scene } from '@babylonjs/core/scene';
import { Mesh } from '@babylonjs/core/Meshes/mesh';
import { VertexData } from '@babylonjs/core/Meshes/mesh.vertexData';
import { Vector3 } from '@babylonjs/core/Maths/math.vector';
import { PBRMaterial } from '@babylonjs/core/Materials/PBR/pbrMaterial';
import { Color3 } from '@babylonjs/core/Maths/math.color';
import { loadOptionalTextureSlot } from '../TextureSlotLoader';
// Iter 35 PR 2 Phase L: SeededRandom + NodeState import 제거 (createStemMesh archived).

// ─────────────────────────────────────────────────────────────────────────
// Catmull-Rom utilities (exported — SkeletonOverlay reuses these).
// ─────────────────────────────────────────────────────────────────────────

/** Catmull-Rom interpolation; p0/p3 are tangent anchors. */
export function catmullRom(
  p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, t: number,
): Vector3 {
  const t2 = t * t;
  const t3 = t2 * t;
  return new Vector3(
    0.5 * (2 * p1.x + (-p0.x + p2.x) * t + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3),
    0.5 * (2 * p1.y + (-p0.y + p2.y) * t + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3),
    0.5 * (2 * p1.z + (-p0.z + p2.z) * t + (2 * p0.z - 5 * p1.z + 4 * p2.z - p3.z) * t2 + (-p0.z + 3 * p1.z - 3 * p2.z + p3.z) * t3),
  );
}

/**
 * Sample a smooth polyline through control points. For N control points
 * and D divisions, outputs (N-1)·D + 1 sample points — first sample is
 * control point 0, last sample is control point N-1, so endpoints are
 * preserved.
 */
export function catmullRomPath(points: Vector3[], divisionsPerSeg: number): Vector3[] {
  if (points.length < 2) return points.slice();
  const out: Vector3[] = [];
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(points.length - 1, i + 2)];
    const steps = i === points.length - 2 ? divisionsPerSeg + 1 : divisionsPerSeg;
    for (let s = 0; s < steps; s++) {
      const t = s / divisionsPerSeg;
      out.push(catmullRom(p0, p1, p2, p3, t));
    }
  }
  return out;
}

// ─────────────────────────────────────────────────────────────────────────
// Stem mesh
// ─────────────────────────────────────────────────────────────────────────

const DEFAULT_RADIAL_SEGMENTS = 8;
const DIVISIONS_PER_NODE = 4;

export interface StemMeshOptions {
  /** Side shoots: pass parent's branch position instead of ground origin.
   *  `undefined` (default) → use (0,0,0). `null` → no prefix at all. */
  origin?: { x: number; y: number; z: number } | null;
  /** Cross-section vertex count. 8 = octagonal (cheap, supporting plants).
   *  12 = visibly round (showcase). Default 8. */
  radialSegments?: number;
  /** 0 = uniform taper. > 0 = swelling at each NodeState's control-point
   *  position (마디감). Typical 0.10–0.20. */
  nodeBulge?: number;
  /** Number of longitudinal grooves around the cross-section. 0 disables.
   *  8 ≈ vascular bundle hint, only noticeable at close range. */
  verticalStripeCount?: number;
  /** Depth of the stripes (0..1 — multiplier on vertex color). 0.06 is
   *  subtle, 0.15 is obvious. */
  stripeDepth?: number;
}

/**
 * Generic curved-tube builder. Used by peduncle / pedicel / etc. Same
 * sweep + per-vertex color machinery as the main stem, but takes
 * pre-computed controlPoints + controlRadii directly (no NodeState
 * plumbing). Useful for shorter anatomical structures.
 */
export function createCurvedTube(
  name: string,
  scene: Scene,
  controlPoints: Vector3[],
  controlRadii: number[],
  options: {
    radialSegments?: number;
    divisionsPerSeg?: number;
    /** Uniform color (overrides woodiness gradient). If omitted, falls
     *  back to woodiness gradient. */
    color?: { r: number; g: number; b: number };
  } = {},
): Mesh | null {
  if (controlPoints.length < 2 || controlPoints.length !== controlRadii.length) return null;
  const radialSegments = Math.max(3, options.radialSegments ?? DEFAULT_RADIAL_SEGMENTS);
  const divisions = Math.max(1, options.divisionsPerSeg ?? DIVISIONS_PER_NODE);
  const curve = catmullRomPath(controlPoints, divisions);
  const curveRadii = sampleRadiiBetween(curve.length, controlRadii, divisions);
  const vd = sweepTube(curve, curveRadii, radialSegments, 0, 0, options.color);
  const mesh = new Mesh(name, scene);
  vd.applyToMesh(mesh);
  return mesh;
}

/**
 * Build a tube mesh through `nodes` using each node's authoritative
 * 3D position (Plan 3b — single source of truth). Per-node `stemRadiusMm`
 * controls the cross-section radius for natural taper; per-node
 * `deflectionRad`/Azimuth from PhysicsModel adds fruit-weight bending
 * on top of the skeleton's wandering curve.
 *
 * Vertex colors encode woodiness — brown at the base, herbaceous green
 * at the tip — and optionally are modulated by `verticalStripeCount`
// Iter 35 PR 2 Phase L — createStemMesh + createStemMeshFromSegments 제거
//   (ShowcasePlant 전용, 사용처 0. SkinMesh는 defaultSkinEngine.render() 사용).

// ─────────────────────────────────────────────────────────────────────────
// Internals
// ─────────────────────────────────────────────────────────────────────────

// Iter 35 PR 2 Phase L — buildControlSpine 제거 (createStemMesh와 함께 dead).

/**
 * Interpolate per-curve-sample radius from per-control values. With
 * `nodeBulge > 0`, samples near a control point get an additional radial
 * swell — produces visible mass at each plant node ("마디감").
 *
 * `catmullRomPath(controls, divisions)` outputs `divisions·(N-1) + 1`
 * samples; sample index k maps to fractional control-point index
 * `k / divisions`. The integer part is the lower control, the fraction
 * is the lerp factor.
 */
function sampleRadiiBetween(
  ringCount: number,
  controlRadii: number[],
  divisionsPerSeg: number,
  nodeBulge = 0,
): number[] {
  const out = new Array<number>(ringCount);
  const N = controlRadii.length;
  for (let i = 0; i < ringCount; i++) {
    const f = i / divisionsPerSeg;
    const lo = Math.min(N - 1, Math.floor(f));
    const hi = Math.min(N - 1, lo + 1);
    const frac = Math.max(0, Math.min(1, f - lo));
    let r = controlRadii[lo] * (1 - frac) + controlRadii[hi] * frac;
    if (nodeBulge > 0) {
      const distFromCtrl = Math.min(frac, 1 - frac);
      const bulge = (1 - distFromCtrl * 2) * nodeBulge;
      r *= 1 + bulge;
    }
    out[i] = r;
  }
  return out;
}

/**
 * Sweep a tapered tube along the supplied curve. radialSegments determines
 * the cross-section polygon count. `stripeCount > 0` modulates per-vertex
 * color with longitudinal grooves (vascular bundle hint). `uniformColor`
 * if supplied overrides the woodiness gradient — used by peduncle / pedicel
 * where a flat hue is more appropriate than a brown↦green axis gradient.
 */
function sweepTube(
  curvePoints: Vector3[],
  curveRadii: number[],
  radialSegments: number,
  stripeCount: number,
  stripeDepth: number,
  uniformColor?: { r: number; g: number; b: number },
): VertexData {
  const ringCount = curvePoints.length;
  const totalSegments = ringCount - 1;
  const colCount = radialSegments + 1;          // +1 to close the cylinder (uv seam)
  const vertCount = ringCount * colCount;

  const positions = new Array<number>(vertCount * 3);
  const normals = new Array<number>(vertCount * 3);
  const colors = new Array<number>(vertCount * 4);
  const uvs = new Array<number>(vertCount * 2);

  const up = new Vector3(0, 1, 0);
  // Scratch vectors — reused inside the per-ring loop to reduce GC churn.
  const tangent = new Vector3();
  const normalDir = new Vector3();
  const binormal = new Vector3();

  for (let i = 0; i < ringCount; i++) {
    const t = totalSegments > 0 ? i / totalSegments : 0;
    const p = curvePoints[i];
    const radius = curveRadii[i];

    // Tangent via central difference (clamped at endpoints).
    const next = i < ringCount - 1 ? curvePoints[i + 1] : p;
    const prev = i > 0 ? curvePoints[i - 1] : p;
    next.subtractToRef(prev, tangent);
    tangent.normalize();

    // Frenet-ish frame — pick a normal perpendicular to tangent. When the
    // tangent is almost parallel to world up, fall back to world-x.
    if (Math.abs(Vector3.Dot(tangent, up)) > 0.99) {
      normalDir.set(1, 0, 0);
    } else {
      Vector3.CrossToRef(up, tangent, normalDir);
      normalDir.normalize();
    }
    Vector3.CrossToRef(tangent, normalDir, binormal);
    binormal.normalize();

    // Woodiness — nonlinear gradient toward base. The transformation is
    // chosen so basal nodes read brown (lignified) and apical nodes read
    // green (herbaceous). uniformColor overrides for peduncle / pedicel.
    let r0: number, g0: number, b0: number;
    if (uniformColor) {
      r0 = uniformColor.r;
      g0 = uniformColor.g;
      b0 = uniformColor.b;
    } else {
      const woodiness = Math.pow(1 - t, 0.6);
      r0 = 0.35 * woodiness + 0.28 * (1 - woodiness);
      g0 = 0.22 * woodiness + 0.55 * (1 - woodiness);
      b0 = 0.12 * woodiness + 0.22 * (1 - woodiness);
    }

    for (let j = 0; j < colCount; j++) {
      const angle = (j / radialSegments) * Math.PI * 2;
      const cosA = Math.cos(angle);
      const sinA = Math.sin(angle);
      const nx = normalDir.x * cosA + binormal.x * sinA;
      const ny = normalDir.y * cosA + binormal.y * sinA;
      const nz = normalDir.z * cosA + binormal.z * sinA;

      const idx = (i * colCount + j) * 3;
      positions[idx]     = p.x + nx * radius;
      positions[idx + 1] = p.y + ny * radius;
      positions[idx + 2] = p.z + nz * radius;
      normals[idx]     = nx;
      normals[idx + 1] = ny;
      normals[idx + 2] = nz;

      // Vertical stripe — darken slightly along `stripeCount` longitudinal
      // grooves. Peaks at the high points (|cos|=1), 0 in valleys.
      let stripeMul = 1;
      if (stripeCount > 0 && stripeDepth > 0) {
        stripeMul = 1 - stripeDepth * Math.abs(Math.cos(stripeCount * angle));
      }

      const cidx = (i * colCount + j) * 4;
      colors[cidx]     = r0 * stripeMul;
      colors[cidx + 1] = g0 * stripeMul;
      colors[cidx + 2] = b0 * stripeMul;
      colors[cidx + 3] = 1;

      const uidx = (i * colCount + j) * 2;
      uvs[uidx]     = j / radialSegments;
      uvs[uidx + 1] = t;
    }
  }

  // Quad-strip indices — two triangles per quad (ring × radial).
  const indices: number[] = new Array((ringCount - 1) * radialSegments * 6);
  let w = 0;
  for (let i = 0; i < ringCount - 1; i++) {
    for (let j = 0; j < radialSegments; j++) {
      const a = i * colCount + j;
      const b2 = a + colCount;
      const c = a + 1;
      const d = b2 + 1;
      indices[w++] = a;  indices[w++] = b2; indices[w++] = c;
      indices[w++] = c;  indices[w++] = b2; indices[w++] = d;
    }
  }

  const vd = new VertexData();
  vd.positions = positions;
  vd.normals = normals;
  vd.colors = colors;
  vd.uvs = uvs;
  vd.indices = indices;
  return vd;
}

// ─────────────────────────────────────────────────────────────────────────
// Material
// ─────────────────────────────────────────────────────────────────────────

const cachedStemMaterial: WeakMap<Scene, PBRMaterial> = new WeakMap();

export function getStemMaterial(scene: Scene): PBRMaterial {
  let mat = cachedStemMaterial.get(scene);
  if (!mat) {
    mat = new PBRMaterial('stemMat', scene);
    mat.albedoColor = new Color3(1, 1, 1);
    mat.useAlphaFromAlbedoTexture = false;
    mat.metallic = 0;
    mat.roughness = 0.85;
    const targetMat = mat;
    loadOptionalTextureSlot(scene, '/textures/stem/stem_normal.png', {
      gammaSpace: false,
    }).then((tex) => {
      if (tex) {
        targetMat.bumpTexture = tex;
        targetMat.invertNormalMapY = false;
        targetMat.invertNormalMapX = false;
      }
    });
    mat.backFaceCulling = true;
    cachedStemMaterial.set(scene, mat);
  }
  return mat;
}
