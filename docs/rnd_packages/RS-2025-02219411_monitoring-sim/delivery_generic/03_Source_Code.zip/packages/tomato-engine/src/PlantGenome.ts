import { SeededRandom } from './SeededRandom';
import type { BotanicalSpec } from './BotanicalSpec';
import { ACTIVE_BOTANICAL } from './ModelRegistry';
import type { Cultivar } from './Cultivar';

export interface PlantGenome {
  seed: number;

  // Growth curve
  heightMaxCm: number;
  heightSigmoidK: number;
  heightSigmoidMid: number;

  // Per-plant phyllotaxis jitter (degrees). Phytomer emergence rate
  // itself is owned by cultivar.phyllochronGDD; this only twists the
  // spiral angle for visual variation.
  phyllotaxisJitter: number;

  // Leaves
  leafSizeMultiplier: number;
  leafletCountBias: number; // -1, 0, or +1
  leafDroopMultiplier: number;
  leafHueBias: number; // color variation

  // Visual
  stemRadiusMultiplier: number;
  fruitOblongFactor: number;

  // Biomechanics
  stemStrengthFactor: number;      // overall stem structural strength
  stemYoungsModulusMPa: number;    // Young's modulus of stem tissue
  stemWoodDensity: number;         // stem tissue density kg/m³
  wireAttachmentHeight: number;    // training wire height (m)

  // Leaf shape
  leafSerrationDepth: number;      // serration tooth amplitude (fraction of width)
  leafSerrationFreq: number;       // teeth per leaflet edge
  leafLobeDepth: number;           // depth of lobing
  leafWaviness: number;            // surface bumpiness amplitude
  leafPetioleLength: number;       // petiole length (m)

  // Internode & leaf expansion (science-based)
  internodeLenCm: number;          // base internode length (cm), real data: 5-8cm
  leafExpansionRate: number;       // leaf expansion sigmoid steepness (k), 0.25-0.45

  // Apex-driven internode elongation (GA-mediated)
  // Real biology: leaf expands → produces GA → GA moves down → internode below elongates
  internodeElongDelay: number;     // delay before elongation starts (days), 3-6
  internodeElongMid: number;       // sigmoid midpoint for elongation (days after delay), 6-10

  // Per-plant stem sway around the vertical anchor (Lever A').
  // Real tomatoes are tied to a twine: they wander left/right but are pulled
  // back toward the vertical line. amplitude × cos(height·freq + phase) gives
  // each plant its own sway pattern; restoring force keeps it bounded.
  swayAmplitude: number;           // dimensionless lean amplitude (~0.02-0.08)
  swayFrequencyRadPerM: number;    // sway rotation per metre of stem height
  swayPhaseOffsetRad: number;      // starting phase (0..2π)

  // Wire-compressed slide azimuth (Lever D). Used once the plant tops out at
  // the overhead wire and the stem is forced sideways. Replaces the old
  // `seed % 17` bucket which collapsed hundreds of plants into 17 directions.
  wireSlideAzimuthRad: number;     // slide direction (0..2π)

  // Planting time offset (days)
  plantingDayOffset: number;
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

/**
 * Iter 29 Phase 5 — GENOME-CULTIVAR-API-01 / -02.
 *
 * generateGenome accepts an optional options bag:
 *   - `cultivar`  → drives leaf-shape distribution overrides (visualProfile)
 *   - `botanical` → drives stem-growth / fruit gompertz distributions
 *
 * Single-arg call form retained for backward compat (CULTIVAR-LEGACY-01):
 *   generateGenome(seed)  ≡ generateGenome(seed, {})
 *                         ≡ generateGenomeWithBotanical(seed, ACTIVE_BOTANICAL.tomato)
 *
 * @param seed     deterministic per-plant seed
 * @param options  optional cultivar + botanical context
 */
export interface GenerateGenomeOptions {
  cultivar?: Cultivar;
  botanical?: BotanicalSpec;
}

export function generateGenome(
  seed: number,
  options?: GenerateGenomeOptions,
): PlantGenome {
  const opts = options ?? {};
  const botanical = opts.botanical ?? ACTIVE_BOTANICAL.tomato;
  const cultivar = opts.cultivar;
  const base = generateGenomeWithBotanical(seed, botanical);
  // Cultivar overrides leaf-shape distributions when present.
  if (!cultivar) return base;
  return applyCultivarLeafShape(base, cultivar);
}

/**
 * Apply cultivar leaf-shape overrides to a base genome.
 * Cherry → narrower serration, finer freq. Beefsteak → broader.
 * Per-plant variation (Gaussian) preserved on top of cultivar-typical baseline.
 *
 * Phase 5 baseline implementation — pulls multiplicative bias from cultivar
 * type. Phase 6 calibration pack adds explicit per-field distributions.
 */
function applyCultivarLeafShape(base: PlantGenome, cultivar: Cultivar): PlantGenome {
  // Cultivar-type multipliers (centered on 1.0; ± from cultivar character).
  let serrationBias = 1.0;
  let lobeBias = 1.0;
  let petioleBias = 1.0;
  switch (cultivar.type) {
    case 'cherry':
      serrationBias = 1.5;   // fine-toothed
      lobeBias = 0.6;        // narrow leaflets, less lobed
      petioleBias = 0.85;
      break;
    case 'beefsteak':
      serrationBias = 0.85;  // softer serration
      lobeBias = 1.5;        // strongly lobed
      petioleBias = 1.20;
      break;
    case 'roma':
      serrationBias = 1.10;
      lobeBias = 0.85;
      petioleBias = 0.90;
      break;
    case 'round':
    default:
      // baseline (no bias)
      break;
  }
  return {
    ...base,
    leafSerrationDepth: clamp(base.leafSerrationDepth * serrationBias, 0.10, 0.30),
    leafLobeDepth: clamp(base.leafLobeDepth * lobeBias, 0.0, 0.20),
    leafPetioleLength: clamp(base.leafPetioleLength * petioleBias, 0.05, 0.18),
  };
}

/**
 * Phase C: read distribution parameters (heightCurve, internode length,
 * elongation delay/midpoint) from the botanical spec. Other fields keep
 * their hardcoded distributions until later migration phases.
 *
 * RNG call order is preserved exactly so default-botanical results are
 * byte-identical to the pre-migration generateGenome(seed).
 */
export function generateGenomeWithBotanical(
  seed: number,
  b: BotanicalSpec,
): PlantGenome {
  const rng = new SeededRandom(seed);
  const hc = b.stemGrowth.heightCurve;
  const mi = b.stemGrowth.matureInternode.lengthDistribution;
  const eDelay = b.stemGrowth.elongation.delayDays;
  const eMid = b.stemGrowth.elongation.midpointDays;

  return {
    seed,

    // Growth curve: read from botanical (heightCurve)
    // NOTE: sigmoidK / sigmoidMid in botanical do not declare min/max
    // (MuSigma not ClampedMuSigma). Keep the legacy clamp ranges here
    // until Phase 2 promotes them to ClampedMuSigma.
    heightMaxCm: clamp(rng.gaussian(hc.maxCm.mu, hc.maxCm.sigma), hc.maxCm.min, hc.maxCm.max),
    heightSigmoidK: clamp(rng.gaussian(hc.sigmoidK.mu, hc.sigmoidK.sigma), 0.04, 0.10),
    heightSigmoidMid: clamp(rng.gaussian(hc.sigmoidMid.mu, hc.sigmoidMid.sigma), 35, 55),

    phyllotaxisJitter: rng.gaussian(0, 8),

    // Leaves (Phase 2 migration target — Leaf Module)
    leafSizeMultiplier: clamp(rng.gaussian(1.0, 0.12), 0.7, 1.3),
    leafletCountBias: Math.round(clamp(rng.gaussian(0, 0.6), -1, 1)),
    leafDroopMultiplier: clamp(rng.gaussian(1.0, 0.15), 0.6, 1.4),
    leafHueBias: rng.gaussian(0, 0.05),

    // Visual
    stemRadiusMultiplier: clamp(rng.gaussian(1.0, 0.1), 0.75, 1.25),
    fruitOblongFactor: clamp(rng.gaussian(1.0, 0.08), 0.82, 1.18),

    // Biomechanics (Phase 4 migration target)
    stemStrengthFactor: clamp(rng.gaussian(1.0, 0.1), 0.75, 1.25),
    stemYoungsModulusMPa: clamp(rng.gaussian(10, 2), 5, 15),
    stemWoodDensity: clamp(rng.gaussian(800, 50), 700, 900),
    wireAttachmentHeight: clamp(rng.gaussian(3.5, 0.1), 3.3, 3.7),

    // Leaf shape (Phase 2 migration target — Leaf Module)
    leafSerrationDepth: clamp(rng.gaussian(0.18, 0.03), 0.10, 0.25),
    leafSerrationFreq: clamp(rng.gaussian(10, 1.5), 7, 14),
    leafLobeDepth: clamp(rng.gaussian(0.08, 0.03), 0.0, 0.15),
    leafWaviness: clamp(rng.gaussian(0.003, 0.001), 0.0, 0.006),
    leafPetioleLength: clamp(rng.gaussian(0.10, 0.015), 0.06, 0.14),

    // Internode length: read from botanical (matureInternode.lengthDistribution)
    internodeLenCm: clamp(rng.gaussian(mi.mu, mi.sigma), mi.min, mi.max),
    // Leaf expansion (Phase 2 migration target)
    leafExpansionRate: clamp(rng.gaussian(0.35, 0.04), 0.25, 0.45),

    // Apex-driven internode elongation: read from botanical (elongation)
    internodeElongDelay: clamp(rng.gaussian(eDelay.mu, eDelay.sigma), eDelay.min, eDelay.max),
    internodeElongMid: clamp(rng.gaussian(eMid.mu, eMid.sigma), eMid.min, eMid.max),

    // Per-plant sway (Lever A'). Hardcoded distribution for now; can move to
    // botanical spec later. RNG calls added at the end so earlier fields stay
    // byte-identical to the pre-sway genome — only the snapshot baseline that
    // covers stem geometry needs refresh.
    //
    // freq is intentionally low (0.1..0.6 rad/m): over a ~3m stem the phase
    // only sweeps ~0.3..1.8 rad, so the lean stays largely in one direction
    // instead of oscillating into a net-zero spiral.
    swayAmplitude: clamp(rng.gaussian(0.10, 0.025), 0.05, 0.15),
    swayFrequencyRadPerM: clamp(rng.gaussian(0.3, 0.15), 0.1, 0.6),
    swayPhaseOffsetRad: rng.range(0, 2 * Math.PI),

    // Wire-compressed slide azimuth (Lever D). Uniform 0..2π instead of the
    // 17-bucket `seed % 17` formula in walkSkeleton.
    wireSlideAzimuthRad: rng.range(0, 2 * Math.PI),

    // Planting offset: some plants are a few days ahead or behind
    plantingDayOffset: clamp(rng.gaussian(0, 2), -5, 5),
  };
}
