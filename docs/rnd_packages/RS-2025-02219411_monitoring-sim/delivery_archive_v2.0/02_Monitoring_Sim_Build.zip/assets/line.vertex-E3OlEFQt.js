import{n as e}from"./chunk-DseTPa7n.js";import{t}from"./shaderStore-Dh1-9BHZ.js";import{t as n}from"./clipPlaneVertexDeclaration-BiFbimuY.js";import{t as r}from"./instancesDeclaration-BlLi3QWt.js";import{t as i}from"./instancesVertex-Dg41tC_I.js";import{t as a}from"./clipPlaneVertex-DVBikZig.js";import{t as o}from"./sceneUboDeclaration-Z4zPso69.js";import{t as s}from"./meshUboDeclaration-nVlSzsIg.js";import{t as c}from"./logDepthDeclaration-CubeGiXn.js";import{t as l}from"./logDepthVertex-DRffph41.js";var u=`lineVertexDeclaration`,d=`uniform mat4 viewProjection;
#define ADDITIONAL_VERTEX_DECLARATION
`;t.IncludesShadersStore[u]||(t.IncludesShadersStore[u]=d);var f={name:u,shader:d},p=`lineUboDeclaration`,m=`layout(std140,column_major) uniform;
#include<sceneUboDeclaration>
#include<meshUboDeclaration>
`;t.IncludesShadersStore[p]||(t.IncludesShadersStore[p]=m);var h={name:p,shader:m},g=e({lineVertexShader:()=>b}),_=`lineVertexShader`,v=`#include<__decl__lineVertex>
#include<instancesDeclaration>
#include<clipPlaneVertexDeclaration>
attribute vec3 position;attribute vec4 normal;uniform float width;uniform float aspectRatio;
#include<logDepthDeclaration>
#define CUSTOM_VERTEX_DEFINITIONS
void main(void) {
#define CUSTOM_VERTEX_MAIN_BEGIN
#include<instancesVertex>
mat4 worldViewProjection=viewProjection*finalWorld;vec4 viewPosition=worldViewProjection*vec4(position,1.0);vec4 viewPositionNext=worldViewProjection*vec4(normal.xyz,1.0);vec2 currentScreen=viewPosition.xy/viewPosition.w;vec2 nextScreen=viewPositionNext.xy/viewPositionNext.w;currentScreen.x*=aspectRatio;nextScreen.x*=aspectRatio;vec2 dir=normalize(nextScreen-currentScreen);vec2 normalDir=vec2(-dir.y,dir.x);normalDir*=width/2.0;normalDir.x/=aspectRatio;vec4 offset=vec4(normalDir*normal.w,0.0,0.0);gl_Position=viewPosition+offset;
#if defined(CLIPPLANE) || defined(CLIPPLANE2) || defined(CLIPPLANE3) || defined(CLIPPLANE4) || defined(CLIPPLANE5) || defined(CLIPPLANE6)
vec4 worldPos=finalWorld*vec4(position,1.0);
#include<clipPlaneVertex>
#endif
#include<logDepthVertex>
#define CUSTOM_VERTEX_MAIN_END
}`;t.ShadersStore[_]||(t.ShadersStore[_]=v);var y=[f,o,s,h,r,n,c,i,a,l];for(let e of y)t.IncludesShadersStore[e.name]||(t.IncludesShadersStore[e.name]=e.shader);var b={name:_,shader:v};export{g as t};