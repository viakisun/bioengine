import{i as e}from"./chunk-DseTPa7n.js";import{t}from"./react-BK-lJ8lG.js";import{t as n}from"./logger-BVTQVNO6.js";import{_ as r,c as i,d as a,f as o,g as s,h as c,l,m as u,p as d,s as f,t as p}from"./jsx-runtime-B9ttvpMf.js";var m=`{
  // Phytosim Scenario · Autonomous Driving, Day 15, Standard Aisle, Sunny
  // 초기 생육 (D15) — 작물이 짧음. 카메라 down-pitch 한계와 다음 모종 이동 정확도 검증.
  "id": "drive-D15-standard-sunny",
  "version": "1.0",
  "domain": "autonomous-driving",
  "consumableBy": ["Twin", "Workbench"],

  "world": {
    "greenhouseConfig": "default-24x34-13beds",
    "activeBeds": [3, 4, 5],
    "plantPlacement": "showcase-D15"
  },

  "crop": {
    "day": 15,
    "seed": "0x1A7E",
    "cultivar": "tomimaru",
    "perturbation": {
      "leafDensityScale": 1.0,
      "internodeScale": 1.0,
      "trussTimingOffset": 0,
      "fruitSetRate": 1.0
    }
  },

  "env": {
    "manualHour": 12,
    "lightingPreset": "default",
    "wind": { "strength": 0.15, "direction": [1, 0, 0.1] },
    "fogDensity": 0
  },

  "robot": {
    "model": "via-agv-6dof-v1",
    "startPose": { "rail": "aisle-3", "x": 0.0 },
    "endEffector": "thinning-cutter",
    "camera": {
      "head": { "lens": 60, "mountHeight": 1.4, "pitch": -10, "yaw": 0 },
      "endEffector": { "lens": 45, "mountHeight": 1.2, "pitch": 0, "yaw": 0 }
    }
  },

  "task": {
    "type": "drive-traverse",
    "speedMps": 0.25,
    "decisionTriggers": ["obstacle"],
    "targets": "bed==3 || bed==4 || bed==5"
  },

  "verify": {
    "successCriteria": [
      { "metric": "fov-fruit-coverage",   "min": 0.85, "note": "D15엔 과실이 거의 없으므로 생장점 coverage로 대체 평가" },
      { "metric": "collision-count",      "max": 0 },
      { "metric": "path-length",          "max": 18.0 },
      { "metric": "task-completion-time", "max": 90 }
    ]
  },

  "meta": {
    "parentId": null,
    "createdBy": "via-pm",
    "createdAt": "2026-06-06T10:00:00Z",
    "description": "초기 생육 표준 통로 정오 햇빛. 베이스라인 시나리오."
  }
}
`,h=`{
  // S1.g — 중기 생육, 표준 통로, 흐림 (중간 난이도 baseline).
  "id": "drive-D45-standard-overcast",
  "version": "1.0",
  "domain": "autonomous-driving",
  "consumableBy": ["Twin", "Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5], "plantPlacement": "showcase-D45" },
  "crop": { "day": 45, "seed": "0x4501", "cultivar": "tomimaru" },
  "env": { "manualHour": 13, "lightingPreset": "overcast", "wind": { "strength": 0.2, "direction": [1, 0, 0.1] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 0.0 }, "endEffector": "none" },
  "task": { "type": "drive-traverse", "speedMps": 0.22, "decisionTriggers": ["obstacle"] },
  "verify": {
    "successCriteria": [
      { "metric": "fov-fruit-coverage", "min": 0.75 },
      { "metric": "collision-count", "max": 0 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "중기 생육 흐림 표준 baseline." }
}
`,g=`{
  // S2.e — 중후기 canopy 침범 (잎이 통로로 들어오기 시작).
  "id": "drive-D70-occluded-canopy",
  "version": "1.0",
  "domain": "autonomous-driving",
  "consumableBy": ["Twin", "Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5], "plantPlacement": "showcase-D70" },
  "crop": { "day": 70, "seed": "0x7022", "cultivar": "tomimaru", "perturbation": { "leafDensityScale": 1.2 } },
  "env": { "manualHour": 14, "lightingPreset": "default", "wind": { "strength": 0.35, "direction": [1, 0, 0.2] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 0 }, "endEffector": "none" },
  "task": { "type": "drive-traverse", "speedMps": 0.18, "decisionTriggers": ["leaf-brushing"] },
  "verify": {
    "successCriteria": [
      { "metric": "fov-fruit-coverage", "min": 0.65 },
      { "metric": "collision-count", "max": 1, "note": "canopy 침범 brushing 1회까지 허용" }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "중후기 canopy 잎 침범." }
}
`,_=`{
  // Phytosim Scenario · Autonomous Driving, Day 90, Narrow Aisle, Backlit
  // 후기 생육 (D90) — 잎 밀도 최대, 통로 침범, 역광. 인식 난이도 高.
  "id": "drive-D90-narrow-backlit",
  "version": "1.0",
  "domain": "autonomous-driving",
  "consumableBy": ["Twin", "Workbench"],

  "world": {
    "greenhouseConfig": "default-24x34-13beds",
    "activeBeds": [3, 4, 5],
    "plantPlacement": "showcase-D90"
  },

  "crop": {
    "day": 90,
    "seed": "0x42A7",
    "cultivar": "tomimaru",
    "perturbation": {
      "leafDensityScale": 1.15,        // 잎 밀도 +15%
      "internodeScale": 1.0,
      "trussTimingOffset": 0,
      "fruitSetRate": 1.0
    }
  },

  "env": {
    "manualHour": 17,                  // 늦은 오후 → 역광
    "lightingPreset": "golden",
    "wind": { "strength": 0.4, "direction": [1, 0, 0.3] },
    "fogDensity": 0
  },

  "robot": {
    "model": "via-agv-6dof-v1",
    "startPose": { "rail": "aisle-3", "x": 0.0 },
    "endEffector": "thinning-cutter",
    "camera": {
      "head": { "lens": 60, "mountHeight": 1.6, "pitch": -5, "yaw": 0 },
      "endEffector": { "lens": 45, "mountHeight": 1.5, "pitch": 0, "yaw": 0 }
    }
  },

  "task": {
    "type": "drive-traverse",
    "speedMps": 0.18,                  // 잎 밀도·역광으로 인해 속도 감소
    "decisionTriggers": ["leaf-brushing", "obstacle", "low-visibility"],
    "targets": "bed==3 || bed==4 || bed==5"
  },

  "greenhouse": {
    "aisleWidthScale": 0.95            // 좁은 통로 시뮬레이션
  },

  "verify": {
    "successCriteria": [
      { "metric": "fov-fruit-coverage",   "min": 0.55, "note": "역광·잎 가림으로 임계 낮춤" },
      { "metric": "collision-count",      "max": 0 },
      { "metric": "path-length",          "max": 22.0 },
      { "metric": "task-completion-time", "max": 150 }
    ]
  },

  "meta": {
    "parentId": null,
    "createdBy": "via-pm",
    "createdAt": "2026-06-06T10:00:00Z",
    "description": "후기 생육·역광·좁은 통로. 자율주행 한계 검증 시나리오."
  }
}
`,v=`{
  // S1.g — 후기 생육, 좁은 통로, 정오 햇빛 (자율주행 표준 후기).
  "id": "drive-D90-narrow-sunny",
  "version": "1.0",
  "domain": "autonomous-driving",
  "consumableBy": ["Twin", "Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5], "plantPlacement": "showcase-D90" },
  "crop": { "day": 90, "seed": "0x9001", "cultivar": "tomimaru", "perturbation": { "leafDensityScale": 1.1 } },
  "env": { "manualHour": 12, "lightingPreset": "noon-bright", "wind": { "strength": 0.3, "direction": [1, 0, 0.2] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 0.0 }, "endEffector": "thinning-cutter" },
  "task": { "type": "drive-traverse", "speedMps": 0.2, "decisionTriggers": ["leaf-brushing", "obstacle"] },
  "greenhouse": { "aisleWidthScale": 0.95 },
  "verify": {
    "successCriteria": [
      { "metric": "fov-fruit-coverage", "min": 0.7 },
      { "metric": "collision-count", "max": 0 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "후기 생육 좁은 통로 정오 햇빛." }
}
`,y=`{
  // S1.g — 다중 베드 전환 (베드 간 hairpin 통과).
  "id": "drive-multi-bed-traverse",
  "version": "1.0",
  "domain": "autonomous-driving",
  "consumableBy": ["Twin"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5, 6, 7], "plantPlacement": "showcase-D60" },
  "crop": { "day": 60, "seed": "0x6001", "cultivar": "tomimaru" },
  "env": { "manualHour": 11, "lightingPreset": "default", "wind": { "strength": 0.15, "direction": [1, 0, 0.1] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 0.0 }, "endEffector": "none" },
  "task": { "type": "drive-traverse", "speedMps": 0.25, "decisionTriggers": ["obstacle", "bed-transition"] },
  "verify": {
    "successCriteria": [
      { "metric": "fov-fruit-coverage", "min": 0.7 },
      { "metric": "collision-count", "max": 0 },
      { "metric": "path-length", "max": 80.0 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "다중 베드 전환 (hairpin 포함)." }
}
`,ee=`{
  // §19 Phenotyping survey — D80 중기 phenotyping (이전 D110은 토마토 과도 성숙 → D80으로 조정 2026-06-09).
  //   - 통로 z=-0.8 기준 좌 2 + 우 2 = 4 active beds (사용자 2026-06-09 요청)
  //   - stride 2 = "딱딱 하나 심고 옆 비우고 하나 심고" 패턴 (사용자 그림).
  //     mockScenario PLANTS_PER_BAG 3→5 변경 후 X 간격 _0.2m 균등 grid_ →
  //     stride 2 = 0.4m 정확 균등 (이전 3 holes는 bag 경계로 0.4/0.2 불규칙).
  //     베드당 75 plant × 4 - 1 showcase = 최대 299 plant. 가운데 기준 linear.
  //   - Phenotyping robot 자동 traverse + gimbal pan auto
  //   - 적엽(deleaf) slider 0~80cm
  //   - 좌상단 384×288 짐벌 카메라 mini-viewport (16:9)
  "id": "phenotyping-D110-survey",
  "version": "1.0",
  "domain": "phenotyping",
  "consumableBy": ["Workbench"],
  "world": {
    "greenhouseConfig": "default-24x34-13beds",
    "activeBeds": [4, 5, 6, 7],
    "plantPlacement": "phenotyping-D110-sparse-h4",
    "bedLayout": {
      "leftCols": 2,
      "rightCols": 2,
      "stride": 2
    }
  },
  "crop": {
    "day": 80,
    "seed": "0xD110",
    "cultivar": "tomimaru",
    "cultivation": {
      "deleafHeightCm": 30,
      "deleafMaxCm": 80,
      "deleafEnabled": true
    }
  },
  "env": {
    "manualHour": 12,
    "lightingPreset": "default"
  },
  "robot": {
    "model": "via-phenotyping-v1",
    "profile": "phenotyping",
    "startPose": { "x": -14 },
    "endEffector": "none",
    "camera": {
      "head": {
        "lens": 60,
        "mountHeight": 1.28
      }
    }
  },
  "task": {
    "type": "spray-survey",
    "speedMps": 0.3,
    "targets": "all-fruits",
    "rule": "left-bed-on-forward,right-bed-on-return"
  },
  "verify": {
    "successCriteria": [
      {
        "metric": "coverage-pct",
        "min": 0.85,
        "note": "전 베드 통과 + 좌·우 모두 캡처"
      }
    ]
  },
  "meta": {
    "createdBy": "kisun@viasoft.ai",
    "createdAt": "2026-06-08",
    "description": "D80 중기 phenotyping (이전 D110에서 -30일 — 토마토 과도 성숙 회피). 좌2/우2 = 4 active beds, stride 2 (딱딱 하나 심고 옆 비우고) = 0.4m 정확 균등 grid, 가운데 기준 linear 확장, 최대 299 plant, 적엽 default 30cm (max 80cm slider), 짐벌 카메라 mini-viewport."
  }
}
`,te=`{
  // Phytosim Scenario · Pruning (적심·곁순 제거), Day 40, Sucker only
  // 초중기 생육 (D40) — 곁순(side shoot) 제거 의사결정.
  "id": "prune-D40-sucker-only",
  "version": "1.0",
  "domain": "pruning",
  "consumableBy": ["Workbench"],

  "world": {
    "greenhouseConfig": "default-24x34-13beds",
    "activeBeds": [3],
    "plantPlacement": "single-plant-D40"
  },

  "crop": {
    "day": 40,
    "seed": "0x3F40",
    "cultivar": "tomimaru",
    "perturbation": {
      "leafDensityScale": 1.0,
      "internodeScale": 1.0,
      "trussTimingOffset": 0,
      "fruitSetRate": 1.0
    }
  },

  "env": {
    "manualHour": 10,
    "lightingPreset": "default",
    "wind": { "strength": 0.0, "direction": [0, 0, 0] },
    "fogDensity": 0
  },

  "robot": {
    "model": "via-agv-6dof-v1",
    "startPose": { "rail": "aisle-3", "x": 4.2 },
    "endEffector": "thinning-cutter",                      // 곁순 절단도 동일 도구
    "camera": {
      "head": { "lens": 45, "mountHeight": 1.4, "pitch": 0, "yaw": 0 },
      "endEffector": { "lens": 30, "mountHeight": 1.3, "pitch": 0, "yaw": 0 }
    }
  },

  "task": {
    "type": "pruning-sucker",
    "speedMps": 0,
    "decisionTriggers": ["sucker-detected"],
    "targets": "isSideShoot && parentAxisIdx==0 && budState=='growing'",
    "rule": "주줄기에 직접 붙은 곁순 중 활성 상태(growing)인 것을 제거"
  },

  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy",    "min": 0.90, "note": "곁순 식별은 비교적 명확" },
      { "metric": "reachability-rate",    "min": 0.95 },
      { "metric": "mask-iou",             "min": 0.80 },
      { "metric": "task-completion-time", "max": 20 }
    ]
  },

  "meta": {
    "parentId": null,
    "createdBy": "via-pm",
    "createdAt": "2026-06-06T10:00:00Z",
    "description": "초중기 곁순 제거. 작업 후 식물 상태 budState='pruned' 동기 검증."
  }
}
`,ne=`{
  // S2.e — 중기 다중 곁순 제거 (3~5개 동시 식별).
  "id": "prune-D55-multi-sucker",
  "version": "1.0",
  "domain": "pruning",
  "consumableBy": ["Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3], "plantPlacement": "single-plant-D55" },
  "crop": { "day": 55, "seed": "0x5511", "cultivar": "tomimaru" },
  "env": { "manualHour": 10, "lightingPreset": "default", "wind": { "strength": 0.0, "direction": [0, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 4.2 }, "endEffector": "thinning-cutter" },
  "task": { "type": "pruning-sucker", "speedMps": 0, "decisionTriggers": ["sucker-detected"], "targets": "isSideShoot && budState=='growing' && nodeIdx<=20", "rule": "상위 20 노드의 활성 곁순 모두 제거" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.90 },
      { "metric": "reachability-rate", "min": 0.90 },
      { "metric": "task-completion-time", "max": 50 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "중기 다중 곁순 제거." }
}
`,b=`{
  // S1.g — 생장점 절단 (시즌 마감 적심).
  "id": "prune-D80-apex-topping",
  "version": "1.0",
  "domain": "pruning",
  "consumableBy": ["Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3], "plantPlacement": "single-plant-D80" },
  "crop": { "day": 80, "seed": "0x8001", "cultivar": "tomimaru" },
  "env": { "manualHour": 10, "lightingPreset": "default", "wind": { "strength": 0.0, "direction": [0, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 4.2 }, "endEffector": "thinning-cutter" },
  "task": { "type": "pruning-apex", "speedMps": 0, "decisionTriggers": ["apex-detected"], "targets": "node==apex", "rule": "생장점 절단 (시즌 마감 시기 표시)" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.92 },
      { "metric": "reachability-rate", "min": 0.95 },
      { "metric": "task-completion-time", "max": 15 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "생장점 절단 (시즌 마감)." }
}
`,x=`{
  // Phytosim Scenario · Recognition Batch, Fruit Classification 6 stages
  // Foundry 전용. 과실 6단계 (ripeStage 0~5) 분류 학습 데이터 생성.
  "id": "recog-batch-fruit-classification",
  "version": "1.0",
  "domain": "recognition",
  "consumableBy": ["Foundry"],

  "world": {
    "greenhouseConfig": "default-24x34-13beds",
    "activeBeds": [3, 4, 5, 6, 7],
    "plantPlacement": "multi-plant-mixed-stages"
  },

  "crop": {
    "day": 75,                          // 다양한 ripeStage가 공존하는 시기
    "seed": "0xFEED",                   // base seed; Foundry가 시드 다양화
    "cultivar": "tomimaru",
    "perturbation": {
      "leafDensityScale": 1.0,
      "internodeScale": 1.0,
      "trussTimingOffset": 0,
      "fruitSetRate": 1.0
    }
  },

  "env": {
    "manualHour": 12,                   // base; Foundry가 매트릭스로 변화
    "lightingPreset": "default",
    "wind": { "strength": 0.2, "direction": [1, 0, 0.1] }
  },

  // Foundry 배치 매트릭스 (Composer의 Variable 토글에 해당)
  // 각 차원의 값을 모든 frame에 곱해서 적용
  "foundry": {
    "matrix": {
      "time-of-day":          [6, 9, 12, 15, 18],
      "light-preset":         ["default", "overcast", "golden", "grow-light"],
      "growth-day":           [60, 75, 90, 105],
      "leaf-density-perturb": [0.8, 1.0, 1.2],
      "camera-angle":         [0, 45, 90, 135, 180, 225, 270, 315],
      "camera-height":        [0.8, 1.2, 1.6],
      "wind-strength":        [0.0, 0.3]
    },
    "seeds": 16,                        // 시드 다양화
    "outputs": ["coco-json", "mask-png", "depth-png", "3d-bbox-jsonl"],
    "framesPerCondition": 1,
    "expectedFrames": 153600            // 5·4·4·3·8·3·2 × 16 = 184320 (예상)
  },

  "task": {
    "type": "recognition-capture",
    "speedMps": 0,
    "targets": "fruit && (visible_fraction > 0.1)",
    "labelClasses": [
      "fruit-stage-0", "fruit-stage-1", "fruit-stage-2",
      "fruit-stage-3", "fruit-stage-4", "fruit-stage-5"
    ]
  },

  "verify": {
    "successCriteria": [
      { "metric": "mask-iou",            "min": 0.85, "note": "RT mesh ID 기반 mask는 high quality 기대" },
      { "metric": "occlusion-error",     "max": 0.10 },
      { "metric": "label-class-balance", "min": 0.05, "note": "각 클래스 ≥5% 비율" }
    ]
  },

  "meta": {
    "parentId": null,
    "createdBy": "via-pm",
    "createdAt": "2026-06-06T10:00:00Z",
    "description": "과실 6단계 분류용 합성 데이터셋. ~15만 장."
  }
}
`,S=`{
  // S2.e — Foundry 다품종 분류 (cultivar 일반화 검증).
  "id": "recog-batch-multi-cultivar",
  "version": "1.0",
  "domain": "recognition",
  "consumableBy": ["Foundry"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5], "plantPlacement": "multi-plant-mixed-stages" },
  "crop": { "day": 75, "seed": "0xCC750", "cultivar": "tomimaru" },
  "env": { "manualHour": 12, "lightingPreset": "default", "wind": { "strength": 0.2, "direction": [1, 0, 0.1] } },
  "foundry": {
    "matrix": {
      "growth-day": [60, 75, 90],
      "camera-angle": [0, 60, 120, 180, 240, 300],
      "camera-height": [1.0, 1.4, 1.8],
      "cultivar": ["tomimaru", "momotaro", "roma"]
    },
    "seeds": 8,
    "outputs": ["coco-json", "mask-png"],
    "framesPerCondition": 1,
    "expectedFrames": 1296
  },
  "task": {
    "type": "recognition-capture",
    "speedMps": 0,
    "labelClasses": [
      "fruit-stage-0", "fruit-stage-1", "fruit-stage-2",
      "fruit-stage-3", "fruit-stage-4", "fruit-stage-5",
      "cultivar-tomimaru", "cultivar-momotaro", "cultivar-roma"
    ]
  },
  "verify": {
    "successCriteria": [
      { "metric": "mask-iou", "min": 0.80 },
      { "metric": "label-class-balance", "min": 0.04 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "다품종 cross-validation 데이터셋." }
}
`,C=`{
  // S2.e — Foundry 가림 회귀 (visible_fraction 0~1 regression).
  "id": "recog-batch-occlusion",
  "version": "1.0",
  "domain": "recognition",
  "consumableBy": ["Foundry"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5], "plantPlacement": "multi-plant-mixed-stages" },
  "crop": { "day": 85, "seed": "0xC8500", "cultivar": "tomimaru", "perturbation": { "leafDensityScale": 1.1 } },
  "env": { "manualHour": 12, "lightingPreset": "default", "wind": { "strength": 0.2, "direction": [1, 0, 0.1] } },
  "foundry": {
    "matrix": {
      "leaf-density-perturb": [0.8, 1.0, 1.2, 1.4],
      "camera-angle": [0, 45, 90, 135, 180, 225, 270, 315],
      "camera-height": [0.8, 1.2, 1.6]
    },
    "seeds": 16,
    "outputs": ["coco-json", "mask-png"],
    "framesPerCondition": 1,
    "expectedFrames": 1536
  },
  "task": {
    "type": "recognition-capture",
    "speedMps": 0,
    "targets": "fruit",
    "labelClasses": ["fruit"]
  },
  "verify": {
    "successCriteria": [
      { "metric": "occlusion-error", "max": 0.10 },
      { "metric": "mask-iou", "min": 0.85 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "과실 가림 정도 회귀 학습용 데이터셋." }
}
`,w=`{
  // S2.e — Foundry 기관 분할 (apex/stem/truss/leaf/fruit instance segmentation).
  "id": "recog-batch-organ-segmentation",
  "version": "1.0",
  "domain": "recognition",
  "consumableBy": ["Foundry"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5], "plantPlacement": "multi-plant-mixed-stages" },
  "crop": { "day": 70, "seed": "0xC7000", "cultivar": "tomimaru" },
  "env": { "manualHour": 12, "lightingPreset": "default", "wind": { "strength": 0.2, "direction": [1, 0, 0.1] } },
  "foundry": {
    "matrix": {
      "time-of-day": [9, 12, 15],
      "growth-day": [45, 60, 75, 90],
      "camera-angle": [0, 60, 120, 180, 240, 300],
      "camera-height": [1.0, 1.6]
    },
    "seeds": 12,
    "outputs": ["coco-json", "mask-png", "3d-bbox-jsonl"],
    "framesPerCondition": 1,
    "expectedFrames": 17280
  },
  "task": {
    "type": "recognition-capture",
    "speedMps": 0,
    "labelClasses": ["apex", "main-stem-segment", "truss-peduncle", "leaf", "fruit"]
  },
  "verify": {
    "successCriteria": [
      { "metric": "mask-iou", "min": 0.82 },
      { "metric": "label-class-balance", "min": 0.05 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "기관 분할 instance segmentation 데이터셋." }
}
`,T=`{
  // S1.g — 고밀도 잎 → 통풍 위험 구역 식별 (방제 의사결정).
  "id": "spray-D60-high-LAI",
  "version": "1.0",
  "domain": "spray",
  "consumableBy": ["Workbench", "Twin"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5], "plantPlacement": "showcase-D60" },
  "crop": { "day": 60, "seed": "0x6201", "cultivar": "tomimaru", "perturbation": { "leafDensityScale": 1.25 } },
  "env": { "manualHour": 12, "lightingPreset": "default", "wind": { "strength": 0.05, "direction": [1, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 0 }, "endEffector": "none" },
  "task": { "type": "spray-survey", "speedMps": 0.15, "decisionTriggers": ["high-density-zone"], "targets": "leafDensity > 0.75 && windFlow < 0.2", "rule": "통풍 부족 + 고밀도 잎 구역을 위험 zone으로 marking" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.75 },
      { "metric": "fov-fruit-coverage", "min": 0.6 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "방제 위험 구역 식별 (고LAI + 통풍 부족)." }
}
`,E=`{
  // S2.e — 후기 스트레스 zone 식별 (잎 노화 + 통풍 부족 + 후기 LAI).
  "id": "spray-D85-late-stress",
  "version": "1.0",
  "domain": "spray",
  "consumableBy": ["Workbench", "Twin"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3, 4, 5, 6, 7], "plantPlacement": "showcase-D85" },
  "crop": { "day": 85, "seed": "0x8521", "cultivar": "tomimaru", "perturbation": { "leafDensityScale": 1.15 } },
  "env": { "manualHour": 13, "lightingPreset": "overcast", "wind": { "strength": 0.05, "direction": [1, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 0 }, "endEffector": "none" },
  "task": { "type": "spray-survey", "speedMps": 0.12, "decisionTriggers": ["stress-zone"], "targets": "leafYellowing > 0.3 && windFlow < 0.15", "rule": "후기 황화 + 통풍 부족 zone marking" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.70 },
      { "metric": "fov-fruit-coverage", "min": 0.55 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "후기 스트레스 zone 식별 (방제)." }
}
`,D=`{
  // S1.g — 첫 화방 단일 적과 (적과 시작기).
  "id": "thin-D50-truss1-single",
  "version": "1.0",
  "domain": "thinning",
  "consumableBy": ["Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3], "plantPlacement": "single-plant-D50" },
  "crop": { "day": 50, "seed": "0x5001", "cultivar": "tomimaru" },
  "env": { "manualHour": 11, "lightingPreset": "default", "wind": { "strength": 0.0, "direction": [0, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 4.2 }, "endEffector": "thinning-cutter" },
  "task": { "type": "thinning-decision", "speedMps": 0, "decisionTriggers": ["fruit-detected"], "targets": "truss==1 && diameterMm < 10", "rule": "첫 화방의 작은 과실 1개 제거" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.85 },
      { "metric": "reachability-rate", "min": 0.95 },
      { "metric": "task-completion-time", "max": 30 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "첫 화방 단일 과실 적과." }
}
`,O=`{
  // S2.e — 2번째 화방 우선순위 적과 의사결정.
  "id": "thin-D60-truss2-priority",
  "version": "1.0",
  "domain": "thinning",
  "consumableBy": ["Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3], "plantPlacement": "single-plant-D60" },
  "crop": { "day": 60, "seed": "0x6022", "cultivar": "tomimaru" },
  "env": { "manualHour": 10, "lightingPreset": "default", "wind": { "strength": 0.0, "direction": [0, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 4.2 }, "endEffector": "thinning-cutter" },
  "task": { "type": "thinning-decision", "speedMps": 0, "decisionTriggers": ["fruit-detected"], "targets": "truss==2 && rank>=4", "rule": "화방 2의 4순위 이하 과실 제거 (3개 유지)" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.88 },
      { "metric": "task-completion-time", "max": 40 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "화방 2 우선순위 적과." }
}
`,k=`{
  // Phytosim Scenario · Thinning (적과), Day 70, Truss 3, Multi-fruit
  // 중기 생육 (D70) — 3번째 화방에서 다중 과실 적과 의사결정.
  "id": "thin-D70-truss3-multi",
  "version": "1.0",
  "domain": "thinning",
  "consumableBy": ["Workbench"],

  "world": {
    "greenhouseConfig": "default-24x34-13beds",
    "activeBeds": [3],
    "plantPlacement": "single-plant-D70"
  },

  "crop": {
    "day": 70,
    "seed": "0x7A33",
    "cultivar": "tomimaru",
    "perturbation": {
      "leafDensityScale": 1.0,
      "internodeScale": 1.0,
      "trussTimingOffset": 0,
      "fruitSetRate": 1.0
    }
  },

  "env": {
    "manualHour": 11,
    "lightingPreset": "default",
    "wind": { "strength": 0.0, "direction": [0, 0, 0] },  // 정밀 작업 → 무풍
    "fogDensity": 0
  },

  "robot": {
    "model": "via-agv-6dof-v1",
    "startPose": { "rail": "aisle-3", "x": 4.2 },         // 단일 작물 정면
    "endEffector": "thinning-cutter",
    "camera": {
      "head": { "lens": 45, "mountHeight": 1.5, "pitch": 0, "yaw": 0 },
      "endEffector": { "lens": 30, "mountHeight": 1.4, "pitch": 0, "yaw": 0 }
    }
  },

  "task": {
    "type": "thinning-decision",
    "speedMps": 0,                                         // 정지 작업
    "decisionTriggers": ["fruit-detected"],
    "targets": "truss==3 && (diameterMm < 12 || occlusion > 0.4)",
    "rule": "화방의 가장 작은 과실 또는 가림 40% 초과 과실을 제거"
  },

  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy",    "min": 0.85, "note": "알고리즘 vs 표준 매뉴얼 일치" },
      { "metric": "reachability-rate",    "min": 0.90 },
      { "metric": "mask-iou",             "min": 0.75 },
      { "metric": "task-completion-time", "max": 30 }
    ]
  },

  "meta": {
    "parentId": null,
    "createdBy": "via-pm",
    "createdAt": "2026-06-06T10:00:00Z",
    "description": "중기 적과 다중 과실 의사결정 검증. 알고리즘 vs 매뉴얼 정확도 핵심."
  }
}
`,A=`{
  // S1.g — 후기 생육 다중 화방 동시 적과 (최난이도 적과).
  "id": "thin-D90-multi-truss",
  "version": "1.0",
  "domain": "thinning",
  "consumableBy": ["Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3], "plantPlacement": "single-plant-D90" },
  "crop": { "day": 90, "seed": "0x9101", "cultivar": "tomimaru" },
  "env": { "manualHour": 11, "lightingPreset": "default", "wind": { "strength": 0.0, "direction": [0, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 4.2 }, "endEffector": "thinning-cutter" },
  "task": { "type": "thinning-decision", "speedMps": 0, "decisionTriggers": ["fruit-detected"], "targets": "truss>=3 && truss<=5 && (diameterMm < 12 || occlusion > 0.4)", "rule": "화방 3~5에서 작거나 가린 과실 제거" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.80 },
      { "metric": "reachability-rate", "min": 0.85 },
      { "metric": "task-completion-time", "max": 90 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "후기 다중 화방 적과." }
}
`,j=`{
  // S2.e — 잎에 가려진 과실 적과 의사결정 (occlusion-aware).
  "id": "thin-occluded-fruit",
  "version": "1.0",
  "domain": "thinning",
  "consumableBy": ["Workbench"],
  "world": { "greenhouseConfig": "default-24x34-13beds", "activeBeds": [3], "plantPlacement": "single-plant-D80" },
  "crop": { "day": 80, "seed": "0x8077", "cultivar": "tomimaru", "perturbation": { "leafDensityScale": 1.3 } },
  "env": { "manualHour": 11, "lightingPreset": "default", "wind": { "strength": 0.0, "direction": [0, 0, 0] } },
  "robot": { "model": "via-agv-6dof-v1", "startPose": { "rail": "aisle-3", "x": 4.2 }, "endEffector": "thinning-cutter" },
  "task": { "type": "thinning-decision", "speedMps": 0, "decisionTriggers": ["fruit-detected"], "targets": "occlusion > 0.5 && truss>=3", "rule": "가림 50% 초과 과실은 시야 확보 우선 제거" },
  "verify": {
    "successCriteria": [
      { "metric": "decision-accuracy", "min": 0.80 },
      { "metric": "occlusion-error", "max": 0.15 }
    ]
  },
  "meta": { "parentId": null, "createdBy": "via-pm", "createdAt": "2026-06-06T10:00:00Z", "description": "잎 가림 과실 적과 의사결정." }
}
`,M=c([a(),a(),a()]),N=o({day:a().int().min(0).max(120),seed:u().regex(/^0x[0-9a-fA-F]+$/),cultivar:u().default(`tomimaru`),perturbation:o({leafDensityScale:a().min(.5).max(1.5).optional(),internodeScale:a().min(.7).max(1.3).optional(),trussTimingOffset:a().min(-10).max(10).optional(),fruitSetRate:a().min(.5).max(1).optional()}).optional(),cultivation:o({deleafHeightCm:a().min(0).max(150).optional(),deleafMaxCm:a().min(0).max(150).optional(),deleafEnabled:l().optional()}).optional()}),P=o({manualHour:a().min(0).max(24),lightingPreset:f([`default`,`overcast`,`golden`,`noon-bright`,`grow-light`]).default(`default`),wind:o({strength:a().min(0).max(1),direction:M}).optional(),fogDensity:a().min(0).max(.1).optional()}),F=o({model:u(),profile:f([`agv-arm`,`phenotyping`]).optional(),startPose:o({rail:u().optional(),x:a().optional()}).or(o({x:a(),y:a(),z:a()})).optional(),endEffector:f([`thinning-cutter`,`gripper`,`none`]).default(`none`),camera:o({head:o({lens:a().optional(),mountHeight:a().optional(),pitch:a().optional(),yaw:a().optional()}).optional(),endEffector:o({lens:a().optional(),mountHeight:a().optional(),pitch:a().optional(),yaw:a().optional()}).optional()}).optional()}).optional(),re=o({type:f([`drive-traverse`,`thinning-decision`,`pruning-sucker`,`pruning-apex`,`spray-survey`,`recognition-capture`,`noop`]),speedMps:a().min(0).max(1).default(0),decisionTriggers:i(u()).optional(),targets:u().optional(),rule:u().optional(),labelClasses:i(u()).optional()}),I=o({successCriteria:i(o({metric:u(),min:a().optional(),max:a().optional(),note:u().optional()}))}),L=o({greenhouseConfig:u().default(`default-24x34-13beds`),activeBeds:i(a().int()).optional(),plantPlacement:u().optional(),bedLayout:o({leftCols:a().int().min(0).max(10),rightCols:a().int().min(0).max(10),stride:a().int().min(1).max(10)}).optional()}),R=o({parentId:u().nullable().optional(),createdBy:u().optional(),createdAt:u().optional(),description:u().optional()}).optional(),z=o({id:u().regex(/^[a-zA-Z0-9-]+$/),version:u(),domain:f([`autonomous-driving`,`thinning`,`pruning`,`spray`,`recognition`,`phenotyping`]),consumableBy:i(f([`Workbench`,`Foundry`,`Twin`])).min(1),world:L,crop:N,env:P,robot:F,task:re,verify:I,greenhouse:o({aisleWidthScale:a().min(.8).max(1.2).optional()}).optional(),foundry:o({matrix:d(u(),i(s([u(),a()]))).optional(),seeds:a().int().positive().optional(),outputs:i(u()).optional(),framesPerCondition:a().int().positive().optional(),expectedFrames:a().int().positive().optional()}).optional(),meta:R}),B=n(`scenarios`),V=Object.assign({"../../docs/proposal/scenarios/drive-D15-standard-sunny.scenario.jsonc":m,"../../docs/proposal/scenarios/drive-D45-standard-overcast.scenario.jsonc":h,"../../docs/proposal/scenarios/drive-D70-occluded-canopy.scenario.jsonc":g,"../../docs/proposal/scenarios/drive-D90-narrow-backlit.scenario.jsonc":_,"../../docs/proposal/scenarios/drive-D90-narrow-sunny.scenario.jsonc":v,"../../docs/proposal/scenarios/drive-multi-bed-traverse.scenario.jsonc":y,"../../docs/proposal/scenarios/phenotyping-D110-survey.scenario.jsonc":ee,"../../docs/proposal/scenarios/prune-D40-sucker-only.scenario.jsonc":te,"../../docs/proposal/scenarios/prune-D55-multi-sucker.scenario.jsonc":ne,"../../docs/proposal/scenarios/prune-D80-apex-topping.scenario.jsonc":b,"../../docs/proposal/scenarios/recog-batch-fruit-classification.scenario.jsonc":x,"../../docs/proposal/scenarios/recog-batch-multi-cultivar.scenario.jsonc":S,"../../docs/proposal/scenarios/recog-batch-occlusion.scenario.jsonc":C,"../../docs/proposal/scenarios/recog-batch-organ-segmentation.scenario.jsonc":w,"../../docs/proposal/scenarios/spray-D60-high-LAI.scenario.jsonc":T,"../../docs/proposal/scenarios/spray-D85-late-stress.scenario.jsonc":E,"../../docs/proposal/scenarios/thin-D50-truss1-single.scenario.jsonc":D,"../../docs/proposal/scenarios/thin-D60-truss2-priority.scenario.jsonc":O,"../../docs/proposal/scenarios/thin-D70-truss3-multi.scenario.jsonc":k,"../../docs/proposal/scenarios/thin-D90-multi-truss.scenario.jsonc":A,"../../docs/proposal/scenarios/thin-occluded-fruit.scenario.jsonc":j}),H=Object.assign({});function U(e){switch(e){case 1:return`InvalidSymbol`;case 2:return`InvalidNumberFormat`;case 3:return`PropertyNameExpected`;case 4:return`ValueExpected`;case 5:return`ColonExpected`;case 6:return`CommaExpected`;case 7:return`CloseBraceExpected`;case 8:return`CloseBracketExpected`;case 9:return`EndOfFileExpected`;case 10:return`InvalidCommentToken`;case 11:return`UnexpectedEndOfComment`;case 12:return`UnexpectedEndOfString`;case 13:return`UnexpectedEndOfNumber`;case 14:return`InvalidUnicode`;case 15:return`InvalidEscapeCharacter`;case 16:return`InvalidCharacter`;default:return`code ${e}`}}function W(e,t){let n=[],i=r(t,n,{allowTrailingComma:!0});if(n.length>0)return{path:e,reason:`jsonc parse: ${n.slice(0,3).map(e=>`${U(e.error)}@offset=${e.offset}`).join(`, `)}${n.length>3?` (+${n.length-3} more)`:``}`};let a=z.safeParse(i);if(!a.success){let t=a.error.issues.slice(0,5).map(e=>`${e.path.length>0?e.path.join(`.`):`(root)`}: ${e.message}`),n=a.error.issues.length>5?` (+${a.error.issues.length-5} more)`:``;return{path:e,reason:`zod: ${t.join(`; `)}${n}`}}return{spec:a.data,path:e}}function G(){let e=[],t=[],n=[...Object.entries(V),...Object.entries(H)];for(let[r,i]of n){let n=W(r,i);`spec`in n?e.push(n):(t.push(n),B.warn(`Scenario load failed: ${n.path} — ${n.reason}`))}let r=new Map;for(let t of e){let e=r.get(t.spec.id);e&&B.warn(`Duplicate scenario id "${t.spec.id}" — ${e} vs ${t.path}`),r.set(t.spec.id,t.path)}return{loaded:e,errors:t}}var K=null;function q(){return K===null&&(K=G()),K}function J(e){let{loaded:t}=q();return t.find(t=>t.spec.id===e)?.spec??null}var Y=e(t(),1),X=p(),Z={"autonomous-driving":`자율주행`,thinning:`적과`,pruning:`적심`,spray:`방제`,recognition:`인식 (Foundry)`,phenotyping:`생육 분석`},Q=[`autonomous-driving`,`thinning`,`pruning`,`spray`,`recognition`,`phenotyping`],ie={all:()=>!0,early:e=>e<=30,mid:e=>e>30&&e<=70,late:e=>e>70},$={all:`전체`,early:`초기 D0~30`,mid:`중기 D30~70`,late:`후기 D70~120`};function ae({onSelect:e,onCancel:t,modeFilter:n,onCompose:r,onOpenMyScenarios:i}){let[a,o]=(0,Y.useState)(null),[s,c]=(0,Y.useState)(``),[l,u]=(0,Y.useState)(`all`),[d,f]=(0,Y.useState)(`all`),p=(0,Y.useMemo)(()=>{let{loaded:e,errors:t}=q(),r=s.trim().toLowerCase(),i=e.map(e=>e.spec).filter(e=>n?e.consumableBy.includes(n):!0).filter(e=>l===`all`?!0:e.domain===l).filter(e=>ie[d](e.crop.day)).filter(e=>r?e.id.toLowerCase().includes(r)||(e.meta?.description??``).toLowerCase().includes(r):!0),a={"autonomous-driving":[],thinning:[],pruning:[],spray:[],recognition:[],phenotyping:[]};for(let e of i)a[e.domain].push(e);return{byDomain:a,total:i.length,errors:t.length}},[n,s,l,d]);return(0,X.jsxs)(`div`,{className:`phytosim-picker`,style:{position:`fixed`,inset:0,background:`var(--p-bg, #111)`,color:`var(--p-fg, #ddd)`,overflow:`auto`,padding:`32px 48px`,display:`flex`,flexDirection:`column`,gap:24},children:[(0,X.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`div`,{style:{fontSize:10,fontWeight:600,textTransform:`uppercase`,letterSpacing:`0.10em`,color:`var(--p-fg-dim, #888)`,marginBottom:6},children:`Scenario Catalog`}),(0,X.jsxs)(`h2`,{style:{margin:0,fontSize:24,fontWeight:600},children:[`시나리오 선택`,n&&(0,X.jsxs)(`span`,{style:{fontSize:13,fontWeight:400,color:`var(--p-fg-dim, #888)`,marginLeft:12},children:[`· `,n,` 모드`]})]}),(0,X.jsxs)(`p`,{style:{margin:`8px 0 0`,fontSize:13,color:`var(--p-fg-muted, #aaa)`},children:[p.total,`개 시나리오 · `,p.errors>0?(0,X.jsxs)(`span`,{style:{color:`#d66`},children:[p.errors,` 로드 실패`]}):`모두 정상`]})]}),(0,X.jsxs)(`div`,{style:{display:`flex`,gap:8},children:[i&&(0,X.jsx)(`button`,{className:`p-btn`,onClick:i,style:{padding:`6px 14px`},title:`저장한 변형 시나리오`,children:`★ My Scenarios`}),r&&(0,X.jsx)(`button`,{className:`p-btn p-btn-primary`,onClick:()=>r(),style:{padding:`6px 14px`},title:`조건 dial로 새 시나리오 작성 (L3.5 Composer)`,children:`+ 새 시나리오`}),t&&(0,X.jsx)(`button`,{className:`p-btn`,onClick:t,style:{padding:`6px 14px`},children:`← 뒤로`})]})]}),(0,X.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:12,flexWrap:`wrap`,padding:12,borderRadius:8,background:`rgba(255,255,255,0.03)`,border:`1px solid var(--p-border, #333)`},children:[(0,X.jsx)(`input`,{type:`search`,value:s,onChange:e=>c(e.currentTarget.value),placeholder:`시나리오 id 또는 설명 검색…`,"aria-label":`시나리오 검색`,style:{flex:`1 1 220px`,minWidth:180,padding:`6px 10px`,border:`1px solid var(--p-border, #333)`,background:`var(--p-bg-deep, #0c0c0c)`,color:`var(--p-fg, #ddd)`,borderRadius:6,fontSize:12}}),(0,X.jsxs)(`div`,{style:{display:`flex`,gap:6,alignItems:`center`,fontSize:11},children:[(0,X.jsx)(`span`,{style:{color:`var(--p-fg-dim, #888)`},children:`도메인`}),(0,X.jsxs)(`select`,{value:l,onChange:e=>u(e.currentTarget.value),"aria-label":`도메인 필터`,style:{padding:`4px 8px`,border:`1px solid var(--p-border, #333)`,background:`var(--p-bg-deep, #0c0c0c)`,color:`var(--p-fg, #ddd)`,borderRadius:6,fontSize:12},children:[(0,X.jsx)(`option`,{value:`all`,children:`전체`}),Q.map(e=>(0,X.jsx)(`option`,{value:e,children:Z[e]},e))]})]}),(0,X.jsxs)(`div`,{style:{display:`flex`,gap:6,alignItems:`center`,fontSize:11},children:[(0,X.jsx)(`span`,{style:{color:`var(--p-fg-dim, #888)`},children:`시기`}),(0,X.jsx)(`div`,{className:`p-seg`,style:{display:`flex`,gap:2},children:Object.keys($).map(e=>(0,X.jsx)(`button`,{className:`p-seg-item ${d===e?`active`:``}`,onClick:()=>f(e),style:{padding:`4px 8px`,fontSize:11,fontWeight:d===e?600:400},children:$[e]},e))})]}),(s||l!==`all`||d!==`all`)&&(0,X.jsx)(`button`,{className:`p-btn`,onClick:()=>{c(``),u(`all`),f(`all`)},style:{padding:`4px 10px`,fontSize:11},title:`필터 초기화`,children:`✕ 초기화`})]}),Q.map(t=>{let n=p.byDomain[t];return n.length===0?null:(0,X.jsxs)(`section`,{"aria-label":Z[t],children:[(0,X.jsxs)(`div`,{style:{fontSize:10,fontWeight:600,textTransform:`uppercase`,letterSpacing:`0.08em`,color:`var(--p-fg-dim, #888)`,marginBottom:10},children:[Z[t],` · `,n.length,`개`]}),(0,X.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(280px, 1fr))`,gap:12},children:n.map(t=>{let n=a===t.id;return(0,X.jsxs)(`button`,{className:`p-surface p-surface-hover`,onClick:()=>{o(t.id),e(t)},style:{textAlign:`left`,padding:14,borderRadius:8,cursor:`pointer`,display:`flex`,flexDirection:`column`,gap:6,border:n?`1px solid var(--p-border-accent, #4080d0)`:`1px solid var(--p-border, #333)`,background:n?`var(--p-accent-muted, #1a2540)`:`transparent`,color:`inherit`},children:[(0,X.jsx)(`div`,{className:`p-mono`,style:{fontSize:11,color:`var(--p-fg-dim, #888)`},children:t.id}),(0,X.jsxs)(`div`,{style:{fontSize:13,fontWeight:500,color:`var(--p-fg, #ddd)`},children:[`Day `,t.crop.day,` · `,t.consumableBy.join(` / `)]}),t.meta?.description&&(0,X.jsx)(`div`,{style:{fontSize:11,lineHeight:1.4,color:`var(--p-fg-muted, #aaa)`},children:t.meta.description})]},t.id)})})]},t)})]})}export{J as n,ae as t};