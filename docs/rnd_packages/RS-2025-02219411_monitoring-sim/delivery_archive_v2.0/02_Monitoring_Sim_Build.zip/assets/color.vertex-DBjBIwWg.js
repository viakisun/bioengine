import{n as e}from"./chunk-DseTPa7n.js";import{t}from"./shaderStore-Dh1-9BHZ.js";import{t as n}from"./bonesDeclaration-BM1L7ZgT.js";import{n as r,t as i}from"./bakedVertexAnimation-XlkocpBC.js";import{t as a}from"./clipPlaneVertexDeclaration-BiFbimuY.js";import{t as o}from"./instancesDeclaration-BlLi3QWt.js";import{t as s}from"./instancesVertex-Dg41tC_I.js";import{t as c}from"./bonesVertex-Di5DxTks.js";import{t as l}from"./clipPlaneVertex-DVBikZig.js";import{t as u}from"./fogVertexDeclaration-CQln7RCe.js";import{t as d}from"./fogVertex-DPo8Lgbf.js";import{t as f}from"./vertexColorMixing-CvPBExs0.js";var p=e({colorVertexShader:()=>_}),m=`colorVertexShader`,h=`attribute vec3 position;
#ifdef VERTEXCOLOR
attribute vec4 color;
#endif
#include<bonesDeclaration>
#include<bakedVertexAnimationDeclaration>
#include<clipPlaneVertexDeclaration>
#include<fogVertexDeclaration>
#ifdef FOG
uniform mat4 view;
#endif
#include<instancesDeclaration>
uniform mat4 viewProjection;
#ifdef MULTIVIEW
uniform mat4 viewProjectionR;
#endif
#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)
varying vec4 vColor;
#endif
#define CUSTOM_VERTEX_DEFINITIONS
void main(void) {
#define CUSTOM_VERTEX_MAIN_BEGIN
#ifdef VERTEXCOLOR
vec4 colorUpdated=color;
#endif
#include<instancesVertex>
#include<bonesVertex>
#include<bakedVertexAnimation>
vec4 worldPos=finalWorld*vec4(position,1.0);
#ifdef MULTIVIEW
if (gl_ViewID_OVR==0u) {gl_Position=viewProjection*worldPos;} else {gl_Position=viewProjectionR*worldPos;}
#else
gl_Position=viewProjection*worldPos;
#endif
#include<clipPlaneVertex>
#include<fogVertex>
#include<vertexColorMixing>
#define CUSTOM_VERTEX_MAIN_END
}`;t.ShadersStore[m]||(t.ShadersStore[m]=h);var g=[n,r,a,u,o,s,c,i,l,d,f];for(let e of g)t.IncludesShadersStore[e.name]||(t.IncludesShadersStore[e.name]=e.shader);var _={name:m,shader:h};export{p as t};