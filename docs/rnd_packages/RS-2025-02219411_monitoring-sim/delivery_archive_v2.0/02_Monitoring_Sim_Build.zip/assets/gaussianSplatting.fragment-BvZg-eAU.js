import{t as e}from"./shaderStore-Dh1-9BHZ.js";import{t}from"./clipPlaneFragment-B1ofUI4l.js";import{t as n}from"./clipPlaneFragmentDeclaration-C5SrBN5u.js";import{t as r}from"./fogFragmentDeclaration-ConGNp1I.js";import{t as i}from"./logDepthFragment-BvluXT7w.js";import{t as a}from"./fogFragment-BOqlKMAk.js";import{t as o}from"./gaussianSplattingFragmentDeclaration-YMzWI8xw.js";import{t as s}from"./logDepthDeclaration-JAoGo_0N.js";var c=`gaussianSplattingPixelShader`,l=`#include<clipPlaneFragmentDeclaration>
#include<logDepthDeclaration>
#include<fogFragmentDeclaration>
varying vColor: vec4f;varying vPosition: vec2f;
#define CUSTOM_FRAGMENT_DEFINITIONS
#include<gaussianSplattingFragmentDeclaration>
@fragment
fn main(input: FragmentInputs)->FragmentOutputs {
#define CUSTOM_FRAGMENT_MAIN_BEGIN
#include<clipPlaneFragment>
var finalColor: vec4f=gaussianColor(input.vColor,input.vPosition);
#define CUSTOM_FRAGMENT_BEFORE_FRAGCOLOR
fragmentOutputs.color=finalColor;
#define CUSTOM_FRAGMENT_MAIN_END
}
`;e.ShadersStoreWGSL[c]||(e.ShadersStoreWGSL[c]=l);var u=[n,s,r,i,a,o,t];for(let t of u)e.IncludesShadersStoreWGSL[t.name]||(e.IncludesShadersStoreWGSL[t.name]=t.shader);var d={name:c,shader:l};export{d as gaussianSplattingPixelShaderWGSL};