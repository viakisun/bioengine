import{n as e}from"./chunk-DseTPa7n.js";import{t}from"./shaderStore-Dh1-9BHZ.js";import{t as n}from"./bonesDeclaration-BM1L7ZgT.js";import{n as r,t as i}from"./bakedVertexAnimation-XlkocpBC.js";import{t as a}from"./morphTargetsVertexGlobalDeclaration-DSJwCCDE.js";import{t as o}from"./morphTargetsVertexDeclaration-DJ5ZsmUb.js";import{t as s}from"./clipPlaneVertexDeclaration-BiFbimuY.js";import{t as c}from"./instancesDeclaration-BlLi3QWt.js";import{t as l}from"./morphTargetsVertexGlobal-BEWb9kLU.js";import{t as u}from"./morphTargetsVertex-BzqKTW0X.js";import{t as d}from"./instancesVertex-Dg41tC_I.js";import{t as f}from"./bonesVertex-Di5DxTks.js";import{t as p}from"./clipPlaneVertex-DVBikZig.js";import{t as m}from"./pointCloudVertex-C1usLZzd.js";var h=`pointCloudVertexDeclaration`,g=`#ifdef POINTSIZE
uniform float pointSize;
#endif
`;t.IncludesShadersStore[h]||(t.IncludesShadersStore[h]=g);var _={name:h,shader:g},v=e({depthVertexShader:()=>S}),y=`depthVertexShader`,b=`attribute vec3 position;
#include<bonesDeclaration>
#include<bakedVertexAnimationDeclaration>
#include<morphTargetsVertexGlobalDeclaration>
#include<morphTargetsVertexDeclaration>[0..maxSimultaneousMorphTargets]
#include<clipPlaneVertexDeclaration>
#include<instancesDeclaration>
uniform mat4 viewProjection;uniform vec2 depthValues;
#if defined(ALPHATEST) || defined(NEED_UV)
varying vec2 vUV;uniform mat4 diffuseMatrix;
#ifdef UV1
attribute vec2 uv;
#endif
#ifdef UV2
attribute vec2 uv2;
#endif
#endif
#ifdef STORE_CAMERASPACE_Z
uniform mat4 view;varying vec4 vViewPos;
#endif
#include<pointCloudVertexDeclaration>
varying float vDepthMetric;
#define CUSTOM_VERTEX_DEFINITIONS
void main(void)
{vec3 positionUpdated=position;
#ifdef UV1
vec2 uvUpdated=uv;
#endif
#ifdef UV2
vec2 uv2Updated=uv2;
#endif
#include<morphTargetsVertexGlobal>
#include<morphTargetsVertex>[0..maxSimultaneousMorphTargets]
#include<instancesVertex>
#include<bonesVertex>
#include<bakedVertexAnimation>
vec4 worldPos=finalWorld*vec4(positionUpdated,1.0);
#include<clipPlaneVertex>
gl_Position=viewProjection*worldPos;
#ifdef STORE_CAMERASPACE_Z
vViewPos=view*worldPos;
#else
#ifdef USE_REVERSE_DEPTHBUFFER
vDepthMetric=((-gl_Position.z+depthValues.x)/(depthValues.y));
#else
vDepthMetric=((gl_Position.z+depthValues.x)/(depthValues.y));
#endif
#endif
#if defined(ALPHATEST) || defined(BASIC_RENDER)
#ifdef UV1
vUV=vec2(diffuseMatrix*vec4(uvUpdated,1.0,0.0));
#endif
#ifdef UV2
vUV=vec2(diffuseMatrix*vec4(uv2Updated,1.0,0.0));
#endif
#endif
#include<pointCloudVertex>
}
`;t.ShadersStore[y]||(t.ShadersStore[y]=b);var x=[n,r,a,o,s,c,_,l,u,d,f,i,p,m];for(let e of x)t.IncludesShadersStore[e.name]||(t.IncludesShadersStore[e.name]=e.shader);var S={name:y,shader:b};export{v as t};