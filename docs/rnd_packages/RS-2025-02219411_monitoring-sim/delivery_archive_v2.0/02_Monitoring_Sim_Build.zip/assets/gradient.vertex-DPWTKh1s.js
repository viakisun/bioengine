import{t as e}from"./shaderStore-Dh1-9BHZ.js";import{t}from"./bonesDeclaration-Bt_SZY3j.js";import{t as n}from"./bonesVertex-dJrcpTO5.js";import{t as r}from"./clipPlaneVertex-lNmXEJ8g.js";import{t as i}from"./clipPlaneVertexDeclaration-CP0vorjf.js";import{t as a}from"./lightVxUboDeclaration-Dr7hsyZ5.js";import{t as o}from"./logDepthDeclaration-JAoGo_0N.js";import{t as s}from"./shadowsVertex-B4kYsTXn.js";import{t as c}from"./bakedVertexAnimationDeclaration-Bi62mRCT.js";import{t as l}from"./instancesDeclaration-FetlJ6RD.js";import{t as u}from"./fogVertexDeclaration-DAzyeK5V.js";import{t as d}from"./instancesVertex-CQtG_BO2.js";import{t as f}from"./bakedVertexAnimation-Bkb96pJl.js";import{t as p}from"./fogVertex-7N-W6I2R.js";import{t as m}from"./logDepthVertex-BUamQIb_.js";import{t as h}from"./vertexColorMixing-BsYdh_3q.js";import{t as g}from"./lightVxFragmentDeclaration-DT8oSwhU.js";var _=`gradientVertexShader`,v=`attribute position: vec3f;
#ifdef NORMAL
attribute normal: vec3f;
#endif
#ifdef UV1
attribute uv: vec2f;
#endif
#ifdef UV2
attribute uv2: vec2f;
#endif
#ifdef VERTEXCOLOR
attribute color: vec4f;
#endif
#include<bonesDeclaration>
#include<bakedVertexAnimationDeclaration>
#include<instancesDeclaration>
uniform view: mat4x4f;uniform viewProjection: mat4x4f;
#ifdef POINTSIZE
uniform pointSize: f32;
#endif
varying vPositionW: vec3f;varying vPosition: vec3f;
#ifdef NORMAL
varying vNormalW: vec3f;
#endif
#ifdef VERTEXCOLOR
varying vColor: vec4f;
#endif
#include<clipPlaneVertexDeclaration>
#include<logDepthDeclaration>
#include<fogVertexDeclaration>
#include<__decl__lightVxFragment>[0..maxSimultaneousLights]
#if defined(CLUSTLIGHT_BATCH) && CLUSTLIGHT_BATCH>0
varying vViewDepth: f32;
#endif
#define CUSTOM_VERTEX_DEFINITIONS
@vertex
fn main(input : VertexInputs)->FragmentInputs {
#define CUSTOM_VERTEX_MAIN_BEGIN
#ifdef VERTEXCOLOR
var colorUpdated: vec4f=vertexInputs.color;
#endif
#include<instancesVertex>
#include<bonesVertex>
#include<bakedVertexAnimation>
var worldPos: vec4f=finalWorld* vec4f(vertexInputs.position,1.0);vertexOutputs.position=uniforms.viewProjection*worldPos;vertexOutputs.vPositionW= worldPos.xyz;vertexOutputs.vPosition=vertexInputs.position;
#ifdef NORMAL
vertexOutputs.vNormalW=normalize(( finalWorld* vec4f(vertexInputs.normal,0.0)).xyz);
#endif
#ifndef UV1
var uv: vec2f= vec2f(0.,0.);
#else
var uv: vec2f=vertexInputs.uv;
#endif
#ifndef UV2
var uv2: vec2f= vec2f(0.,0.);
#else
var uv2: vec2f=vertexInputs.uv2;
#endif
#include<clipPlaneVertex>
#include<logDepthVertex>
#include<fogVertex>
#include<shadowsVertex>[0..maxSimultaneousLights]
#include<vertexColorMixing>
#define CUSTOM_VERTEX_MAIN_END
}
`;e.ShadersStoreWGSL[_]||(e.ShadersStoreWGSL[_]=v);var y=[t,c,l,i,o,u,g,a,d,n,f,r,m,p,s,h];for(let t of y)e.IncludesShadersStoreWGSL[t.name]||(e.IncludesShadersStoreWGSL[t.name]=t.shader);var b={name:_,shader:v};export{b as gradientVertexShaderWGSL};