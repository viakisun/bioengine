import{n as e}from"./chunk-DseTPa7n.js";import{t}from"./shaderStore-Dh1-9BHZ.js";import{t as n}from"./logDepthDeclaration-CubeGiXn.js";import{t as r}from"./fogFragmentDeclaration-DyJR43fA.js";import{t as i}from"./logDepthFragment-Ceddli7p.js";import{t as a}from"./fogFragment-2MXDnM7w.js";import{t as o}from"./imageProcessingCompatibility-CklpxoXH.js";var s=e({spritesPixelShader:()=>d}),c=`spritesPixelShader`,l=`#ifdef LOGARITHMICDEPTH
#extension GL_EXT_frag_depth : enable
#endif
uniform bool alphaTest;varying vec4 vColor;varying vec2 vUV;uniform sampler2D diffuseSampler;
#include<fogFragmentDeclaration>
#include<logDepthDeclaration>
#define CUSTOM_FRAGMENT_DEFINITIONS
#ifdef PIXEL_PERFECT
vec2 uvPixelPerfect(vec2 uv) {vec2 res=vec2(textureSize(diffuseSampler,0));uv=uv*res;vec2 seam=floor(uv+0.5);uv=seam+clamp((uv-seam)/fwidth(uv),-0.5,0.5);return uv/res;}
#endif
void main(void) {
#define CUSTOM_FRAGMENT_MAIN_BEGIN
#ifdef PIXEL_PERFECT
vec2 uv=uvPixelPerfect(vUV);
#else
vec2 uv=vUV;
#endif
vec4 color=texture2D(diffuseSampler,uv);float fAlphaTest=float(alphaTest);if (fAlphaTest != 0.)
{if (color.a<0.95)
discard;}
color*=vColor;
#include<logDepthFragment>
#include<fogFragment>
gl_FragColor=color;
#include<imageProcessingCompatibility>
#define CUSTOM_FRAGMENT_MAIN_END
}`;t.ShadersStore[c]||(t.ShadersStore[c]=l);var u=[r,n,i,a,o];for(let e of u)t.IncludesShadersStore[e.name]||(t.IncludesShadersStore[e.name]=e.shader);var d={name:c,shader:l};export{s as t};