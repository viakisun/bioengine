import{n as e}from"./chunk-DseTPa7n.js";import{t}from"./shaderStore-Dh1-9BHZ.js";import{t as n}from"./helperFunctions-CbIWkB0Y.js";import{t as r}from"./imageProcessingDeclaration-ot1_kd8F.js";import{t as i}from"./imageProcessingFunctions-1BtV76r8.js";var a=e({imageProcessingPixelShaderWGSL:()=>l}),o=`imageProcessingPixelShader`,s=`varying vUV: vec2f;var textureSamplerSampler: sampler;var textureSampler: texture_2d<f32>;
#include<imageProcessingDeclaration>
#include<helperFunctions>
#include<imageProcessingFunctions>
#define CUSTOM_FRAGMENT_DEFINITIONS
@fragment
fn main(input: FragmentInputs)->FragmentOutputs {var result: vec4f=textureSample(textureSampler,textureSamplerSampler,input.vUV);result=vec4f(max(result.rgb,vec3f(0.)),result.a);
#ifdef IMAGEPROCESSING
#ifndef FROMLINEARSPACE
result=vec4f(toLinearSpaceVec3(result.rgb),result.a);
#endif
result=applyImageProcessing(result);
#else
#ifdef FROMLINEARSPACE
result=applyImageProcessing(result);
#endif
#endif
fragmentOutputs.color=result;}`;t.ShadersStoreWGSL[o]||(t.ShadersStoreWGSL[o]=s);var c=[r,n,i];for(let e of c)t.IncludesShadersStoreWGSL[e.name]||(t.IncludesShadersStoreWGSL[e.name]=e.shader);var l={name:o,shader:s};export{a as t};