import{t as e}from"./shaderStore-Dh1-9BHZ.js";import{t}from"./bonesDeclaration-BM1L7ZgT.js";import{n,t as r}from"./bakedVertexAnimation-XlkocpBC.js";import{t as i}from"./clipPlaneVertexDeclaration-BiFbimuY.js";import{t as a}from"./instancesDeclaration-BlLi3QWt.js";import{t as o}from"./instancesVertex-Dg41tC_I.js";import{t as s}from"./bonesVertex-Di5DxTks.js";import{t as c}from"./clipPlaneVertex-DVBikZig.js";import{t as l}from"./fogVertexDeclaration-CQln7RCe.js";import{t as u}from"./logDepthDeclaration-CubeGiXn.js";import{t as d}from"./fogVertex-DPo8Lgbf.js";import{t as f}from"./shadowsVertex-CvMwuRtQ.js";import{t as p}from"./vertexColorMixing-CvPBExs0.js";import{t as m}from"./logDepthVertex-DRffph41.js";import{t as h}from"./lightFragmentDeclaration-D6nVFNQW.js";import{t as g}from"./lightUboDeclaration-LyDQ70q3.js";var _=`gradientVertexShader`,v=`precision highp float;attribute vec3 position;
#ifdef NORMAL
attribute vec3 normal;
#endif
#ifdef UV1
attribute vec2 uv;
#endif
#ifdef UV2
attribute vec2 uv2;
#endif
#ifdef VERTEXCOLOR
attribute vec4 color;
#endif
#include<bonesDeclaration>
#include<bakedVertexAnimationDeclaration>
#include<instancesDeclaration>
uniform mat4 view;uniform mat4 viewProjection;
#ifdef POINTSIZE
uniform float pointSize;
#endif
varying vec3 vPositionW;varying vec3 vPosition;
#ifdef NORMAL
varying vec3 vNormalW;
#endif
#ifdef VERTEXCOLOR
varying vec4 vColor;
#endif
#include<clipPlaneVertexDeclaration>
#include<logDepthDeclaration>
#include<fogVertexDeclaration>
#include<__decl__lightFragment>[0..maxSimultaneousLights]
#if defined(CLUSTLIGHT_BATCH) && CLUSTLIGHT_BATCH>0
varying float vViewDepth;
#endif
#define CUSTOM_VERTEX_DEFINITIONS
void main(void) {
#define CUSTOM_VERTEX_MAIN_BEGIN
#ifdef VERTEXCOLOR
vec4 colorUpdated=color;
#endif
#include<instancesVertex>
#include<bonesVertex>
#include<bakedVertexAnimation>
vec4 worldPos=finalWorld*vec4(position,1.0);gl_Position=viewProjection*worldPos;vPositionW=vec3(worldPos);vPosition=position;
#ifdef NORMAL
vNormalW=normalize(vec3(finalWorld*vec4(normal,0.0)));
#endif
#ifndef UV1
vec2 uv=vec2(0.,0.);
#endif
#ifndef UV2
vec2 uv2=vec2(0.,0.);
#endif
#include<clipPlaneVertex>
#include<logDepthVertex>
#include<fogVertex>
#include<shadowsVertex>[0..maxSimultaneousLights]
#include<vertexColorMixing>
#if defined(POINTSIZE) && !defined(WEBGPU)
gl_PointSize=pointSize;
#endif
#define CUSTOM_VERTEX_MAIN_END
}
`;e.ShadersStore[_]||(e.ShadersStore[_]=v);var y=[t,n,a,i,u,l,h,g,o,s,r,c,m,d,f,p];for(let t of y)e.IncludesShadersStore[t.name]||(e.IncludesShadersStore[t.name]=t.shader);var b={name:_,shader:v};export{b as gradientVertexShader};