import{n as e}from"./chunk-DseTPa7n.js";import{t}from"./shaderStore-Dh1-9BHZ.js";import{t as n}from"./bonesDeclaration-BM1L7ZgT.js";import{n as r,t as i}from"./bakedVertexAnimation-XlkocpBC.js";import{t as a}from"./morphTargetsVertexGlobalDeclaration-DSJwCCDE.js";import{t as o}from"./morphTargetsVertexDeclaration-DJ5ZsmUb.js";import{t as s}from"./clipPlaneVertexDeclaration-BiFbimuY.js";import{t as c}from"./instancesDeclaration-BlLi3QWt.js";import{t as l}from"./morphTargetsVertexGlobal-BEWb9kLU.js";import{t as u}from"./morphTargetsVertex-BzqKTW0X.js";import{t as d}from"./instancesVertex-Dg41tC_I.js";import{t as f}from"./bonesVertex-Di5DxTks.js";import{t as p}from"./clipPlaneVertex-DVBikZig.js";import{t as m}from"./logDepthDeclaration-CubeGiXn.js";import{t as h}from"./logDepthVertex-DRffph41.js";var g=e({outlineVertexShader:()=>b}),_=`outlineVertexShader`,v=`attribute vec3 position;attribute vec3 normal;
#include<bonesDeclaration>
#include<bakedVertexAnimationDeclaration>
#include<morphTargetsVertexGlobalDeclaration>
#include<morphTargetsVertexDeclaration>[0..maxSimultaneousMorphTargets]
#include<clipPlaneVertexDeclaration>
uniform float offset;
#include<instancesDeclaration>
uniform mat4 viewProjection;
#ifdef ALPHATEST
varying vec2 vUV;uniform mat4 diffuseMatrix;
#ifdef UV1
attribute vec2 uv;
#endif
#ifdef UV2
attribute vec2 uv2;
#endif
#endif
#include<logDepthDeclaration>
#define CUSTOM_VERTEX_DEFINITIONS
void main(void)
{vec3 positionUpdated=position;vec3 normalUpdated=normal;
#ifdef UV1
vec2 uvUpdated=uv;
#endif
#ifdef UV2
vec2 uv2Updated=uv2;
#endif
#include<morphTargetsVertexGlobal>
#include<morphTargetsVertex>[0..maxSimultaneousMorphTargets]
vec3 offsetPosition=positionUpdated+(normalUpdated*offset);
#include<instancesVertex>
#include<bonesVertex>
#include<bakedVertexAnimation>
vec4 worldPos=finalWorld*vec4(offsetPosition,1.0);gl_Position=viewProjection*worldPos;
#ifdef ALPHATEST
#ifdef UV1
vUV=vec2(diffuseMatrix*vec4(uvUpdated,1.0,0.0));
#endif
#ifdef UV2
vUV=vec2(diffuseMatrix*vec4(uv2Updated,1.0,0.0));
#endif
#endif
#include<clipPlaneVertex>
#include<logDepthVertex>
}
`;t.ShadersStore[_]||(t.ShadersStore[_]=v);var y=[n,r,a,o,s,c,m,l,u,d,f,i,p,h];for(let e of y)t.IncludesShadersStore[e.name]||(t.IncludesShadersStore[e.name]=e.shader);var b={name:_,shader:v};export{g as t};