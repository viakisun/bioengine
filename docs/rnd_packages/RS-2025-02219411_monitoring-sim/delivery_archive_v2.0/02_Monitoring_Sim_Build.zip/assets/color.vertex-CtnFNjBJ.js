import{n as e}from"./chunk-DseTPa7n.js";import{t}from"./shaderStore-Dh1-9BHZ.js";import{t as n}from"./bonesDeclaration-Bt_SZY3j.js";import{t as r}from"./bonesVertex-dJrcpTO5.js";import{t as i}from"./clipPlaneVertex-lNmXEJ8g.js";import{t as a}from"./clipPlaneVertexDeclaration-CP0vorjf.js";import{t as o}from"./bakedVertexAnimationDeclaration-Bi62mRCT.js";import{t as s}from"./instancesDeclaration-FetlJ6RD.js";import{t as c}from"./fogVertexDeclaration-DAzyeK5V.js";import{t as l}from"./instancesVertex-CQtG_BO2.js";import{t as u}from"./bakedVertexAnimation-Bkb96pJl.js";import{t as d}from"./fogVertex-7N-W6I2R.js";import{t as f}from"./vertexColorMixing-BsYdh_3q.js";var p=e({colorVertexShaderWGSL:()=>_}),m=`colorVertexShader`,h=`attribute position: vec3f;
#ifdef VERTEXCOLOR
attribute color: vec4f;
#endif
#include<bonesDeclaration>
#include<bakedVertexAnimationDeclaration>
#include<clipPlaneVertexDeclaration>
#include<fogVertexDeclaration>
#ifdef FOG
uniform view: mat4x4f;
#endif
#include<instancesDeclaration>
uniform viewProjection: mat4x4f;
#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)
varying vColor: vec4f;
#endif
#define CUSTOM_VERTEX_DEFINITIONS
@vertex
fn main(input : VertexInputs)->FragmentInputs {
#define CUSTOM_VERTEX_MAIN_BEGIN
#ifdef VERTEXCOLOR
var colorUpdated: vec4f=vertexInputs.color;
#endif
#include<instancesVertex>
#include<bonesVertex>
#include<bakedVertexAnimation>
var worldPos: vec4f=finalWorld* vec4f(vertexInputs.position,1.0);vertexOutputs.position=uniforms.viewProjection*worldPos;
#include<clipPlaneVertex>
#include<fogVertex>
#include<vertexColorMixing>
#define CUSTOM_VERTEX_MAIN_END
}`;t.ShadersStoreWGSL[m]||(t.ShadersStoreWGSL[m]=h);var g=[n,o,a,c,s,l,r,u,i,d,f];for(let e of g)t.IncludesShadersStoreWGSL[e.name]||(t.IncludesShadersStoreWGSL[e.name]=e.shader);var _={name:m,shader:h};export{p as t};