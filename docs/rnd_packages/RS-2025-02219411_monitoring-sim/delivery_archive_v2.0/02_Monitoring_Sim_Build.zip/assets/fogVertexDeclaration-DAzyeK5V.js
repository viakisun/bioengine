import{t as e}from"./shaderStore-Dh1-9BHZ.js";var t=`fogVertexDeclaration`,n=`#ifdef FOG
varying vFogDistance: vec3f;
#endif
`;e.IncludesShadersStoreWGSL[t]||(e.IncludesShadersStoreWGSL[t]=n);var r={name:t,shader:n};export{r as t};