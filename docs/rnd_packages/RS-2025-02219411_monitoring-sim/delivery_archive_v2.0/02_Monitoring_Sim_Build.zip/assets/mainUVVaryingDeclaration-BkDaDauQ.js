import{t as e}from"./shaderStore-Dh1-9BHZ.js";var t=`mainUVVaryingDeclaration`,n=`#ifdef MAINUV{X}
varying vec2 vMainUV{X};
#endif
`;e.IncludesShadersStore[t]||(e.IncludesShadersStore[t]=n);var r={name:t,shader:n};export{r as t};