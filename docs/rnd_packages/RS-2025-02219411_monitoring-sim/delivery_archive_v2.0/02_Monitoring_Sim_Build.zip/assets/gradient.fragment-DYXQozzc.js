import{t as e}from"./shaderStore-Dh1-9BHZ.js";import{t}from"./helperFunctions-DtGAP6Gz.js";import{t as n}from"./logDepthDeclaration-CubeGiXn.js";import{t as r}from"./lightFragmentDeclaration-D6nVFNQW.js";import{t as i}from"./lightUboDeclaration-LyDQ70q3.js";import{t as a}from"./clipPlaneFragmentDeclaration-BgSUnePU.js";import{t as o}from"./fogFragmentDeclaration-DyJR43fA.js";import{t as s}from"./shadowsFragmentFunctions-DQMxh1oR.js";import"./ltcHelperFunctions-BScdtvEy.js";import"./clusteredLightingFunctions-BTTG67Xe.js";import{t as c}from"./clipPlaneFragment-D4v6vcDq.js";import{t as l}from"./depthPrePass-D2vfI8nc.js";import{t as u}from"./lightFragment-D2HTJMSk.js";import{t as d}from"./logDepthFragment-Ceddli7p.js";import{t as f}from"./fogFragment-2MXDnM7w.js";import{t as p}from"./lightsFragmentFunctions-Crld1FZS.js";import{t as m}from"./imageProcessingCompatibility-CklpxoXH.js";var h=`gradientPixelShader`,g=`precision highp float;uniform vec4 vEyePosition;uniform vec4 topColor;uniform vec4 bottomColor;uniform float offset;uniform float scale;uniform float smoothness;varying vec3 vPositionW;varying vec3 vPosition;
#ifdef NORMAL
varying vec3 vNormalW;
#endif
#ifdef VERTEXCOLOR
varying vec4 vColor;
#endif
#include<helperFunctions>
#include<__decl__lightFragment>[0]
#include<__decl__lightFragment>[1]
#include<__decl__lightFragment>[2]
#include<__decl__lightFragment>[3]
#include<lightsFragmentFunctions>
#include<shadowsFragmentFunctions>
#include<clipPlaneFragmentDeclaration>
#ifdef LOGARITHMICDEPTH
#extension GL_EXT_frag_depth : enable
#endif
#include<logDepthDeclaration>
#include<fogFragmentDeclaration>
#if defined(CLUSTLIGHT_BATCH) && CLUSTLIGHT_BATCH>0
varying float vViewDepth;
#endif
#define CUSTOM_FRAGMENT_DEFINITIONS
void main(void) {
#define CUSTOM_FRAGMENT_MAIN_BEGIN
#include<clipPlaneFragment>
vec3 viewDirectionW=normalize(vEyePosition.xyz-vPositionW);float h=vPosition.y*scale+offset;float mysmoothness=clamp(smoothness,0.01,max(smoothness,10.));vec4 baseColor=mix(bottomColor,topColor,max(pow(max(h,0.0),mysmoothness),0.0));vec3 diffuseColor=baseColor.rgb;float alpha=baseColor.a;
#ifdef ALPHATEST
if (baseColor.a<0.4)
discard;
#endif
#include<depthPrePass>
#ifdef VERTEXCOLOR
baseColor.rgb*=vColor.rgb;
#endif
#ifdef NORMAL
vec3 normalW=normalize(vNormalW);
#else
vec3 normalW=vec3(1.0,1.0,1.0);
#endif
#ifdef EMISSIVE
vec3 diffuseBase=baseColor.rgb;
#else
vec3 diffuseBase=vec3(0.,0.,0.);
#endif
lightingInfo info;float shadow=1.;float glossiness=0.;float aggShadow=0.;float numLights=0.;
#include<lightFragment>[0..maxSimultaneousLights]
#if defined(VERTEXALPHA) || defined(INSTANCESCOLOR) && defined(INSTANCES)
alpha*=vColor.a;
#endif
vec3 finalDiffuse=clamp(diffuseBase*diffuseColor,0.0,1.0)*baseColor.rgb;vec4 color=vec4(finalDiffuse,alpha);
#include<logDepthFragment>
#include<fogFragment>
gl_FragColor=color;
#include<imageProcessingCompatibility>
#define CUSTOM_FRAGMENT_MAIN_END
}
`;e.ShadersStore[h]||(e.ShadersStore[h]=g);var _=[t,r,i,p,s,a,n,o,c,l,u,d,f,m];for(let t of _)e.IncludesShadersStore[t.name]||(e.IncludesShadersStore[t.name]=t.shader);var v={name:h,shader:g};export{v as gradientPixelShader};