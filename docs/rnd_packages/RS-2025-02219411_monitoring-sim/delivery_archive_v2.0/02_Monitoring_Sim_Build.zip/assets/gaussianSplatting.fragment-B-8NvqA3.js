import{t as e}from"./shaderStore-Dh1-9BHZ.js";import{t}from"./logDepthDeclaration-CubeGiXn.js";import{t as n}from"./clipPlaneFragmentDeclaration-BgSUnePU.js";import{t as r}from"./fogFragmentDeclaration-DyJR43fA.js";import{t as i}from"./clipPlaneFragment-D4v6vcDq.js";import{t as a}from"./logDepthFragment-Ceddli7p.js";import{t as o}from"./fogFragment-2MXDnM7w.js";import{gaussianSplattingFragmentDeclaration as s}from"./gaussianSplattingFragmentDeclaration-BSucWWcN.js";var c=`gaussianSplattingPixelShader`,l=`#include<clipPlaneFragmentDeclaration>
#include<logDepthDeclaration>
#include<fogFragmentDeclaration>
varying vec4 vColor;varying vec2 vPosition;
#define CUSTOM_FRAGMENT_DEFINITIONS
#include<gaussianSplattingFragmentDeclaration>
void main () {
#define CUSTOM_FRAGMENT_MAIN_BEGIN
#include<clipPlaneFragment>
vec4 finalColor=gaussianColor(vColor);
#define CUSTOM_FRAGMENT_BEFORE_FRAGCOLOR
gl_FragColor=finalColor;
#define CUSTOM_FRAGMENT_MAIN_END
}
`;e.ShadersStore[c]||(e.ShadersStore[c]=l);var u=[n,t,r,a,o,s,i];for(let t of u)e.IncludesShadersStore[t.name]||(e.IncludesShadersStore[t.name]=t.shader);var d={name:c,shader:l};export{d as gaussianSplattingPixelShader};