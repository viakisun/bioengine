from __future__ import annotations

from .common import *


def build_completion(data: dict[str, Any], out: Path):
    doc = new_doc()
    add_cover(doc, "완료보고서", get(data, "work.short_item_name"), "납품 산출물 및 검수 완료 결과 보고")
    add_para(doc, "완료 결과: 산출물 제출 확인 및 검수 완료 / 보완사항 없음", size=11.5, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, after=10)
    add_heading(doc, "1", "보고 요지")
    add_para(doc, f"본 보고서는 {get(data, 'vendor.name')}이 수행한 {get(data, 'work.short_item_name')} 제작 건의 납품 산출물 제출 및 검수 결과를 정리하기 위한 완료보고서이다.")
    add_para(doc, f"수행업체는 {get(data, 'schedule.delivery_date')} 시제품 본체 1식과 납품자료를 제출하였고, {get(data, 'schedule.inspection_date')} 검수 결과 보완사항 없이 적합으로 확인되었다.")
    add_heading(doc, "2", "기본 정보")
    kv_table(doc, [
        ("문서명", "완료보고서"),
        ("작성일", get(data, "schedule.completion_date")),
        ("제작명", get(data, "work.short_item_name")),
        ("수행업체", get(data, "vendor.name")),
        ("수행기간", get(data, "schedule.contract_period")),
        ("납품일", get(data, "schedule.delivery_date")),
        ("검수일", get(data, "schedule.inspection_date")),
        ("검수 결과", "적합 / 보완사항 없음"),
    ])
    add_heading(doc, "3", "과제 정보")
    kv_table(doc, project_rows(data) + [("집행 비목", get(data, "money.budget_item"))])
    add_heading(doc, "4", "진행 경과")
    data_table(doc, ["구분", "일자", "내용"], [
        ["기안", get(data, "schedule.memo_date"), "제작 추진"],
        ["과업지시", get(data, "schedule.task_order_date"), "수행 범위 및 검수 기준 제시"],
        ["발주·계약", get(data, "schedule.contract_date"), "과업 착수"],
        ["납품", get(data, "schedule.delivery_date"), "산출물 1식 및 납품자료 제출"],
        ["검수", get(data, "schedule.inspection_date"), "제출 산출물 및 검수 기준 확인"],
    ])
    add_heading(doc, "5", "납품 산출물")
    data_table(doc, ["번호", "산출물", "파일명 또는 경로"], [
        [idx, item.get("name", ""), item.get("file_hint", "")]
        for idx, item in enumerate(get(data, "work.deliverables", []), 1)
    ], size=7.8)
    add_heading(doc, "6", "검수 결과")
    data_table(doc, ["검수 항목", "결과"], [[c.get("item", ""), "적합"] for c in get(data, "work.inspection_criteria", [])] + [["보완사항", "없음"]])
    add_heading(doc, "7", "종합")
    add_para(doc, f"{get(data, 'vendor.name')}은 과업지시서에 따른 산출물을 제출하였다. {get(data, 'project.performing_org')}는 {get(data, 'schedule.inspection_date')} 제출 산출물을 검수하였으며, 보완사항 없이 적합으로 판정하였다. 이에 본 과업을 완료 보고한다.")
    return save_doc(doc, out)
